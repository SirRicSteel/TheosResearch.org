"""
Test Backend API
Verify that FastAPI endpoints work correctly
"""

import sys
import asyncio
from httpx import AsyncClient
import json

print("=" * 60)
print("THEOS AI - Backend API Test")
print("=" * 60)

# Test configuration
BASE_URL = "http://localhost:8000"
test_user_email = "testuser@example.com"
test_user_password = "testpassword123"
access_token = None

async def run_tests():
    """Run all API tests"""
    global access_token
    
    async with AsyncClient(base_url=BASE_URL) as client:
        
        # Test 1: Health check
        print("\n[Test 1] Health check...")
        try:
            response = await client.get("/health")
            assert response.status_code == 200
            data = response.json()
            assert data["status"] == "healthy"
            print(f"✅ Health check passed: {data['service']} v{data['version']}")
        except Exception as e:
            print(f"❌ Health check failed: {e}")
            return False
        
        # Test 2: Register user
        print("\n[Test 2] User registration...")
        try:
            response = await client.post("/api/auth/register", json={
                "email": test_user_email,
                "password": test_user_password,
                "full_name": "Test User"
            })
            
            if response.status_code == 400:
                # User might already exist, try login instead
                print("   User already exists, will test login instead")
            else:
                assert response.status_code == 200
                data = response.json()
                access_token = data["access_token"]
                assert access_token is not None
                print(f"✅ Registration successful: {data['user']['email']}")
        except Exception as e:
            print(f"⚠️  Registration test inconclusive: {e}")
        
        # Test 3: Login
        print("\n[Test 3] User login...")
        try:
            response = await client.post("/api/auth/login", json={
                "email": test_user_email,
                "password": test_user_password
            })
            assert response.status_code == 200
            data = response.json()
            access_token = data["access_token"]
            assert access_token is not None
            print(f"✅ Login successful: Token received")
        except Exception as e:
            print(f"❌ Login failed: {e}")
            return False
        
        # Test 4: Get current user
        print("\n[Test 4] Get current user...")
        try:
            response = await client.get(
                "/api/auth/me",
                headers={"Authorization": f"Bearer {access_token}"}
            )
            assert response.status_code == 200
            data = response.json()
            assert data["email"] == test_user_email
            print(f"✅ User info retrieved: {data['full_name']}")
            print(f"   Subscription: {data['subscription_tier']}")
            print(f"   Queries used today: {data['queries_used_today']}")
        except Exception as e:
            print(f"❌ Get user failed: {e}")
            return False
        
        # Test 5: Ask a question (without THEOS for now)
        print("\n[Test 5] Ask question endpoint...")
        print("   (Skipping - requires THEOS integration)")
        print("   ⚠️  Will test after THEOS service is verified")
        
        # Test 6: Get question history
        print("\n[Test 6] Get question history...")
        try:
            response = await client.get(
                "/api/questions/history",
                headers={"Authorization": f"Bearer {access_token}"}
            )
            assert response.status_code == 200
            data = response.json()
            print(f"✅ History retrieved: {len(data)} question(s)")
        except Exception as e:
            print(f"❌ Get history failed: {e}")
            return False
    
    return True


# Main execution
if __name__ == "__main__":
    print("\n⚠️  NOTE: This test requires the API server to be running.")
    print("   Start server with: uvicorn main:app --reload")
    print("   Then run this test in another terminal.\n")
    
    try:
        result = asyncio.run(run_tests())
        
        if result:
            print("\n" + "=" * 60)
            print("✅ CORE API TESTS PASSED")
            print("=" * 60)
            print("\nBackend API layer is SOLID (except THEOS integration).")
            print("Next: Test THEOS service integration.")
        else:
            print("\n" + "=" * 60)
            print("❌ SOME TESTS FAILED")
            print("=" * 60)
            sys.exit(1)
            
    except Exception as e:
        print(f"\n❌ Test suite failed: {e}")
        print("\nMake sure the API server is running:")
        print("  cd /home/ubuntu/theos-ai-app/backend")
        print("  source venv/bin/activate")
        print("  uvicorn main:app --reload")
        sys.exit(1)
