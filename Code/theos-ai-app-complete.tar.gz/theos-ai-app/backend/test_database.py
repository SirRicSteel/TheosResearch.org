"""
Test Database Layer
Verify that database models and connections work
"""

import sys
import os

# Simple test without heavy dependencies
print("=" * 60)
print("THEOS AI - Database Layer Test")
print("=" * 60)

# Test 1: Import models
print("\n[Test 1] Importing models...")
try:
    from models import User, Question, QueryPack, UserRole, SubscriptionTier, Base
    print("✅ Models imported successfully")
except Exception as e:
    print(f"❌ Failed to import models: {e}")
    sys.exit(1)

# Test 2: Create database engine
print("\n[Test 2] Creating database engine...")
try:
    from sqlalchemy import create_engine
    from sqlalchemy.pool import StaticPool
    
    # Use in-memory SQLite for testing
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    print("✅ Database engine created")
except Exception as e:
    print(f"❌ Failed to create engine: {e}")
    sys.exit(1)

# Test 3: Create tables
print("\n[Test 3] Creating tables...")
try:
    Base.metadata.create_all(bind=engine)
    print("✅ Tables created successfully")
    
    # List tables
    from sqlalchemy import inspect
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    print(f"   Tables: {', '.join(tables)}")
except Exception as e:
    print(f"❌ Failed to create tables: {e}")
    sys.exit(1)

# Test 4: Create session and test user
print("\n[Test 4] Testing user creation...")
try:
    from sqlalchemy.orm import sessionmaker
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    
    # Create test user
    test_user = User(
        email="test@example.com",
        hashed_password="hashed_password_here",
        full_name="Test User",
        role=UserRole.USER,
        subscription_tier=SubscriptionTier.FREE
    )
    
    db.add(test_user)
    db.commit()
    db.refresh(test_user)
    
    print(f"✅ User created: ID={test_user.id}, Email={test_user.email}")
except Exception as e:
    print(f"❌ Failed to create user: {e}")
    db.rollback()
    sys.exit(1)

# Test 5: Query user
print("\n[Test 5] Testing user query...")
try:
    queried_user = db.query(User).filter(User.email == "test@example.com").first()
    assert queried_user is not None
    assert queried_user.email == "test@example.com"
    assert queried_user.subscription_tier == SubscriptionTier.FREE
    print(f"✅ User queried successfully: {queried_user.full_name}")
except Exception as e:
    print(f"❌ Failed to query user: {e}")
    sys.exit(1)

# Test 6: Create question
print("\n[Test 6] Testing question creation...")
try:
    test_question = Question(
        user_id=test_user.id,
        question_text="What is consciousness?",
        status="processing"
    )
    
    db.add(test_question)
    db.commit()
    db.refresh(test_question)
    
    print(f"✅ Question created: ID={test_question.id}")
except Exception as e:
    print(f"❌ Failed to create question: {e}")
    db.rollback()
    sys.exit(1)

# Test 7: Test relationship
print("\n[Test 7] Testing user-question relationship...")
try:
    user_with_questions = db.query(User).filter(User.id == test_user.id).first()
    assert len(user_with_questions.questions) == 1
    assert user_with_questions.questions[0].question_text == "What is consciousness?"
    print(f"✅ Relationship works: User has {len(user_with_questions.questions)} question(s)")
except Exception as e:
    print(f"❌ Failed to test relationship: {e}")
    sys.exit(1)

# Test 8: Test query pack
print("\n[Test 8] Testing query pack creation...")
try:
    test_pack = QueryPack(
        user_id=test_user.id,
        pack_size=100,
        queries_remaining=100,
        price_paid=7.00
    )
    
    db.add(test_pack)
    db.commit()
    db.refresh(test_pack)
    
    print(f"✅ Query pack created: ID={test_pack.id}, Size={test_pack.pack_size}")
except Exception as e:
    print(f"❌ Failed to create query pack: {e}")
    db.rollback()
    sys.exit(1)

# Cleanup
db.close()

print("\n" + "=" * 60)
print("✅ ALL DATABASE TESTS PASSED")
print("=" * 60)
print("\nDatabase layer is SOLID. Ready to build API on top.")
