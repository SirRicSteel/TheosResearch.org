"""
THEOS Reasoning Service
Integrates THEOS 2.0 CEO Engine with the web application
"""

import sys
import os
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import json

# Add theos-plugin to path
sys.path.insert(0, "/home/ubuntu/theos-plugin")

from theos.ceo_engine import CEOEngine, CEOAssessment, QualityMetrics
from theos.core import THEOSConfig


class THEOSReasoningService:
    """
    Service for processing questions through THEOS 2.0 reasoning engine.
    Provides streaming updates for real-time visualization.
    """
    
    def __init__(self):
        """Initialize THEOS CEO Engine"""
        self.ceo = CEOEngine()
        self.config = THEOSConfig()
        
    def process_question(
        self,
        question: str,
        callback: Optional[callable] = None
    ) -> Dict:
        """
        Process a question through THEOS reasoning.
        
        Args:
            question: The question to process
            callback: Optional callback for streaming updates
                     callback(cycle, status_update)
        
        Returns:
            Dict with complete reasoning result
        """
        start_time = datetime.utcnow()
        
        # Step 1: CEO assesses the question
        assessment = self.ceo.assess_question(question)
        
        if callback:
            callback(0, {
                "phase": "assessment",
                "ceo_status": {
                    "phase": "processing",
                    "message": f"Assessing question complexity...",
                    "quality": None,
                    "convergence": None
                },
                "left_status": {"phase": "idle", "message": "Waiting..."},
                "right_status": {"phase": "idle", "message": "Waiting..."}
            })
        
        # Step 2: Run reasoning cycles
        left_outputs = []
        right_outputs = []
        cycle = 0
        max_cycles = 10  # Safety limit
        
        while cycle < max_cycles:
            cycle += 1
            
            # Simulate Left Engine (Constructive)
            left_output = self._simulate_left_engine(question, cycle, left_outputs)
            left_outputs.append(left_output)
            
            if callback:
                callback(cycle, {
                    "phase": "processing",
                    "cycle": cycle,
                    "ceo_status": {
                        "phase": "processing",
                        "message": f"Monitoring quality... (Cycle {cycle})",
                        "quality": None,
                        "convergence": None
                    },
                    "left_status": {
                        "phase": "processing",
                        "message": left_output[:100] + "..."
                    },
                    "right_status": {"phase": "processing", "message": "Waiting for left engine..."}
                })
            
            # Simulate Right Engine (Deconstructive)
            right_output = self._simulate_right_engine(question, cycle, left_output, right_outputs)
            right_outputs.append(right_output)
            
            # CEO monitors quality
            previous_left = left_outputs[-2] if len(left_outputs) > 1 else None
            previous_right = right_outputs[-2] if len(right_outputs) > 1 else None
            
            quality_metrics = self.ceo.monitor_quality(
                cycle=cycle,
                left_output=left_output,
                right_output=right_output,
                previous_left=previous_left,
                previous_right=previous_right
            )
            
            if callback:
                callback(cycle, {
                    "phase": "processing",
                    "cycle": cycle,
                    "ceo_status": {
                        "phase": "processing",
                        "message": f"Quality: {quality_metrics.overall_quality:.1f}/10",
                        "quality": quality_metrics.overall_quality,
                        "convergence": quality_metrics.convergence_score
                    },
                    "left_status": {
                        "phase": "processing",
                        "message": left_output[:100] + "..."
                    },
                    "right_status": {
                        "phase": "processing",
                        "message": right_output[:100] + "..."
                    }
                })
            
            # CEO decides whether to continue
            should_stop, reasoning = self.ceo.decide_convergence(
                cycle=cycle,
                assessment=assessment,
                current_quality=quality_metrics
            )
            
            if should_stop:
                break
        
        # Step 3: CEO synthesizes final answer
        if callback:
            callback(cycle, {
                "phase": "converging",
                "cycle": cycle,
                "ceo_status": {
                    "phase": "converging",
                    "message": "Synthesizing perspectives...",
                    "quality": quality_metrics.overall_quality,
                    "convergence": quality_metrics.convergence_score
                },
                "left_status": {"phase": "converging", "message": "Final validation..."},
                "right_status": {"phase": "converging", "message": "Final critique..."}
            })
        
        final_answer = self.ceo.synthesize(
            question=question,
            left_outputs=left_outputs,
            right_outputs=right_outputs,
            assessment=assessment,
            final_quality=quality_metrics
        )
        
        end_time = datetime.utcnow()
        processing_time = (end_time - start_time).total_seconds()
        
        if callback:
            callback(cycle, {
                "phase": "complete",
                "cycle": cycle,
                "ceo_status": {
                    "phase": "complete",
                    "message": "Synthesis complete!",
                    "quality": quality_metrics.overall_quality,
                    "convergence": quality_metrics.convergence_score
                },
                "left_status": {"phase": "complete", "message": "Analysis complete"},
                "right_status": {"phase": "complete", "message": "Validation complete"}
            })
        
        # Return complete result
        return {
            "question": question,
            "answer": final_answer,
            "assessment": {
                "complexity": assessment.complexity.value,
                "ethical_flag": assessment.ethical_flag.value,
                "required_depth": assessment.required_depth,
                "domain_tags": assessment.domain_tags
            },
            "reasoning": {
                "left_outputs": left_outputs,
                "right_outputs": right_outputs,
                "cycles_used": cycle
            },
            "metrics": {
                "final_quality_score": quality_metrics.overall_quality,
                "final_convergence": quality_metrics.convergence_score,
                "processing_time_seconds": processing_time
            }
        }
    
    def _simulate_left_engine(
        self,
        question: str,
        cycle: int,
        previous_outputs: List[str]
    ) -> str:
        """
        Simulate Left Engine (Constructive reasoning).
        In production, this would call actual LLM.
        """
        prompts = {
            1: f"Analyze the question: '{question}'. Build a constructive hypothesis using inductive, abductive, and deductive reasoning.",
            2: f"Refine the constructive analysis. Consider additional patterns and strengthen the logical foundation.",
            3: f"Validate the constructive reasoning. Ensure logical consistency and completeness."
        }
        
        prompt = prompts.get(cycle, f"Continue constructive analysis (Cycle {cycle})")
        
        # TODO: Replace with actual LLM call
        # For now, return structured placeholder
        return f"[Left Engine Cycle {cycle}] {prompt}\n\nConstructive insight: This requires systematic analysis of the core concepts and their relationships."
    
    def _simulate_right_engine(
        self,
        question: str,
        cycle: int,
        left_output: str,
        previous_outputs: List[str]
    ) -> str:
        """
        Simulate Right Engine (Deconstructive reasoning).
        In production, this would call actual LLM.
        """
        prompts = {
            1: f"Challenge the constructive analysis. Identify assumptions and potential flaws.",
            2: f"Test the refined analysis for contradictions and gaps.",
            3: f"Provide final critique and identify remaining uncertainties."
        }
        
        prompt = prompts.get(cycle, f"Continue deconstructive critique (Cycle {cycle})")
        
        # TODO: Replace with actual LLM call
        return f"[Right Engine Cycle {cycle}] {prompt}\n\nDeconstructive critique: We must question the underlying assumptions and consider alternative perspectives."


# Global service instance
_theos_service = None

def get_theos_service() -> THEOSReasoningService:
    """Get or create THEOS service singleton"""
    global _theos_service
    if _theos_service is None:
        _theos_service = THEOSReasoningService()
    return _theos_service
