"""
THEOS AI Database Models
SQLAlchemy models for the THEOS AI application
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class UserRole(str, enum.Enum):
    """User roles"""
    USER = "user"
    ADMIN = "admin"


class SubscriptionTier(str, enum.Enum):
    """Subscription tiers"""
    FREE = "free"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


class User(Base):
    """User accounts"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(320), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    role = Column(Enum(UserRole), default=UserRole.USER, nullable=False)
    
    # Subscription
    subscription_tier = Column(Enum(SubscriptionTier), default=SubscriptionTier.FREE, nullable=False)
    stripe_customer_id = Column(String(255), unique=True)
    stripe_subscription_id = Column(String(255))
    
    # Usage tracking
    queries_used_today = Column(Integer, default=0, nullable=False)
    queries_used_month = Column(Integer, default=0, nullable=False)
    total_queries = Column(Integer, default=0, nullable=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    last_login = Column(DateTime)
    
    # Relationships
    questions = relationship("Question", back_populates="user", cascade="all, delete-orphan")
    query_packs = relationship("QueryPack", back_populates="user", cascade="all, delete-orphan")


class Question(Base):
    """Questions asked by users"""
    __tablename__ = "questions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Question content
    question_text = Column(Text, nullable=False)
    
    # CEO Assessment
    complexity = Column(String(20))  # low, medium, high, extreme
    ethical_flag = Column(String(20))  # none, minor, moderate, critical
    required_depth = Column(Integer)  # minimum cycles required
    domain_tags = Column(Text)  # JSON array of domain tags
    
    # Answer content
    answer_text = Column(Text)
    left_outputs = Column(Text)  # JSON array
    right_outputs = Column(Text)  # JSON array
    
    # Quality metrics
    cycles_used = Column(Integer)
    final_quality_score = Column(Float)  # 0-10
    final_convergence = Column(Float)  # 0-1
    processing_time_seconds = Column(Float)
    
    # Status
    status = Column(String(20), default="processing")  # processing, complete, error
    error_message = Column(Text)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    completed_at = Column(DateTime)
    
    # Relationships
    user = relationship("User", back_populates="questions")


class QueryPack(Base):
    """Query packs purchased by users"""
    __tablename__ = "query_packs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Pack details
    pack_size = Column(Integer, nullable=False)  # 25, 100, 500
    queries_remaining = Column(Integer, nullable=False)
    price_paid = Column(Float, nullable=False)  # in USD
    
    # Payment
    stripe_payment_intent_id = Column(String(255))
    stripe_charge_id = Column(String(255))
    
    # Status
    is_active = Column(Boolean, default=True, nullable=False)
    
    # Timestamps
    purchased_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime)  # Optional expiration
    
    # Relationships
    user = relationship("User", back_populates="query_packs")


class UsageLog(Base):
    """Daily usage logs for analytics"""
    __tablename__ = "usage_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    date = Column(DateTime, nullable=False, index=True)
    
    # Daily stats
    queries_count = Column(Integer, default=0)
    avg_quality_score = Column(Float)
    avg_cycles = Column(Float)
    avg_processing_time = Column(Float)
    
    # Complexity breakdown
    low_complexity_count = Column(Integer, default=0)
    medium_complexity_count = Column(Integer, default=0)
    high_complexity_count = Column(Integer, default=0)
    extreme_complexity_count = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class SystemMetrics(Base):
    """System-wide metrics for monitoring"""
    __tablename__ = "system_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    
    # Usage metrics
    total_users = Column(Integer, default=0)
    active_users_today = Column(Integer, default=0)
    total_questions_today = Column(Integer, default=0)
    
    # Performance metrics
    avg_response_time = Column(Float)
    avg_quality_score = Column(Float)
    cache_hit_rate = Column(Float)
    
    # Revenue metrics
    revenue_today = Column(Float, default=0.0)
    revenue_month = Column(Float, default=0.0)
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
