"""
THEOS AI Backend API
FastAPI application with authentication, reasoning, and payments
"""

from fastapi import FastAPI, Depends, HTTPException, status, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime, timedelta
import os
import json

from database import get_db, init_db
from models import User, Question, QueryPack, UserRole, SubscriptionTier
from theos_service import get_theos_service
from auth import (
    create_access_token,
    verify_password,
    get_password_hash,
    decode_access_token
)

# Initialize FastAPI app
app = FastAPI(
    title="THEOS AI API",
    description="Advanced AI Reasoning Platform with Three-Engine Architecture",
    version="2.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # TODO: Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Initialize database on startup
@app.on_event("startup")
async def startup_event():
    init_db()
    print("🚀 THEOS AI Backend started successfully")


# ============================================================================
# Pydantic Models (Request/Response schemas)
# ============================================================================

class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


class QuestionRequest(BaseModel):
    question: str


class QuestionResponse(BaseModel):
    id: int
    question: str
    answer: Optional[str]
    complexity: Optional[str]
    cycles_used: Optional[int]
    quality_score: Optional[float]
    status: str
    created_at: datetime


# ============================================================================
# Authentication Helpers
# ============================================================================

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """Get current authenticated user"""
    token = credentials.credentials
    payload = decode_access_token(token)
    
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )
    
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()
    
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    
    return user


# ============================================================================
# Authentication Endpoints
# ============================================================================

@app.post("/api/auth/register", response_model=TokenResponse)
async def register(user_data: UserRegister, db: Session = Depends(get_db)):
    """Register a new user"""
    
    # Check if user exists
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Create new user
    new_user = User(
        email=user_data.email,
        hashed_password=get_password_hash(user_data.password),
        full_name=user_data.full_name,
        subscription_tier=SubscriptionTier.FREE
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # Create access token
    access_token = create_access_token(data={"sub": str(new_user.id)})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": new_user.id,
            "email": new_user.email,
            "full_name": new_user.full_name,
            "subscription_tier": new_user.subscription_tier.value
        }
    }


@app.post("/api/auth/login", response_model=TokenResponse)
async def login(credentials: UserLogin, db: Session = Depends(get_db)):
    """Login user"""
    
    # Find user
    user = db.query(User).filter(User.email == credentials.email).first()
    
    if not user or not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password"
        )
    
    # Update last login
    user.last_login = datetime.utcnow()
    db.commit()
    
    # Create access token
    access_token = create_access_token(data={"sub": str(user.id)})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "subscription_tier": user.subscription_tier.value,
            "queries_used_today": user.queries_used_today
        }
    }


@app.get("/api/auth/me")
async def get_me(current_user: User = Depends(get_current_user)):
    """Get current user info"""
    return {
        "id": current_user.id,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "subscription_tier": current_user.subscription_tier.value,
        "queries_used_today": current_user.queries_used_today,
        "queries_used_month": current_user.queries_used_month,
        "total_queries": current_user.total_queries
    }


# ============================================================================
# THEOS Reasoning Endpoints
# ============================================================================

@app.post("/api/reason", response_model=QuestionResponse)
async def ask_question(
    request: QuestionRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Process a question through THEOS reasoning.
    Deducts one query from user's quota.
    """
    
    # Check if user has queries remaining
    if current_user.subscription_tier == SubscriptionTier.FREE:
        if current_user.queries_used_today >= 10:
            raise HTTPException(
                status_code=status.HTTP_402_PAYMENT_REQUIRED,
                detail="Daily free quota exceeded. Please purchase query packs."
            )
    
    # Create question record
    question = Question(
        user_id=current_user.id,
        question_text=request.question,
        status="processing"
    )
    db.add(question)
    db.commit()
    db.refresh(question)
    
    try:
        # Process through THEOS
        theos = get_theos_service()
        result = theos.process_question(request.question)
        
        # Update question with results
        question.answer_text = result["answer"]
        question.complexity = result["assessment"]["complexity"]
        question.ethical_flag = result["assessment"]["ethical_flag"]
        question.required_depth = result["assessment"]["required_depth"]
        question.domain_tags = json.dumps(result["assessment"]["domain_tags"])
        question.left_outputs = json.dumps(result["reasoning"]["left_outputs"])
        question.right_outputs = json.dumps(result["reasoning"]["right_outputs"])
        question.cycles_used = result["reasoning"]["cycles_used"]
        question.final_quality_score = result["metrics"]["final_quality_score"]
        question.final_convergence = result["metrics"]["final_convergence"]
        question.processing_time_seconds = result["metrics"]["processing_time_seconds"]
        question.status = "complete"
        question.completed_at = datetime.utcnow()
        
        # Update user usage
        current_user.queries_used_today += 1
        current_user.queries_used_month += 1
        current_user.total_queries += 1
        
        db.commit()
        db.refresh(question)
        
        return QuestionResponse(
            id=question.id,
            question=question.question_text,
            answer=question.answer_text,
            complexity=question.complexity,
            cycles_used=question.cycles_used,
            quality_score=question.final_quality_score,
            status=question.status,
            created_at=question.created_at
        )
        
    except Exception as e:
        question.status = "error"
        question.error_message = str(e)
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Reasoning failed: {str(e)}"
        )


@app.websocket("/ws/reason")
async def websocket_reason(
    websocket: WebSocket,
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for real-time reasoning with visualization updates.
    """
    await websocket.accept()
    
    try:
        # Receive question
        data = await websocket.receive_json()
        question_text = data.get("question")
        token = data.get("token")
        
        # Verify token
        payload = decode_access_token(token)
        if not payload:
            await websocket.send_json({"error": "Invalid token"})
            await websocket.close()
            return
        
        user_id = int(payload.get("sub"))
        user = db.query(User).filter(User.id == user_id).first()
        
        if not user:
            await websocket.send_json({"error": "User not found"})
            await websocket.close()
            return
        
        # Check quota
        if user.subscription_tier == SubscriptionTier.FREE and user.queries_used_today >= 10:
            await websocket.send_json({"error": "Daily quota exceeded"})
            await websocket.close()
            return
        
        # Create question record
        question = Question(
            user_id=user.id,
            question_text=question_text,
            status="processing"
        )
        db.add(question)
        db.commit()
        db.refresh(question)
        
        # Process with streaming updates
        theos = get_theos_service()
        
        async def callback(cycle, status_update):
            """Send real-time updates to client"""
            await websocket.send_json({
                "type": "status_update",
                "cycle": cycle,
                **status_update
            })
        
        result = theos.process_question(question_text, callback=callback)
        
        # Update question
        question.answer_text = result["answer"]
        question.complexity = result["assessment"]["complexity"]
        question.cycles_used = result["reasoning"]["cycles_used"]
        question.final_quality_score = result["metrics"]["final_quality_score"]
        question.status = "complete"
        question.completed_at = datetime.utcnow()
        
        # Update user usage
        user.queries_used_today += 1
        user.queries_used_month += 1
        user.total_queries += 1
        
        db.commit()
        
        # Send final result
        await websocket.send_json({
            "type": "complete",
            "result": result
        })
        
    except WebSocketDisconnect:
        print("WebSocket disconnected")
    except Exception as e:
        await websocket.send_json({"type": "error", "message": str(e)})
    finally:
        await websocket.close()


@app.get("/api/questions/history")
async def get_question_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    limit: int = 50
):
    """Get user's question history"""
    questions = db.query(Question).filter(
        Question.user_id == current_user.id
    ).order_by(Question.created_at.desc()).limit(limit).all()
    
    return [
        {
            "id": q.id,
            "question": q.question_text,
            "answer": q.answer_text,
            "complexity": q.complexity,
            "quality_score": q.final_quality_score,
            "created_at": q.created_at
        }
        for q in questions
    ]


# ============================================================================
# Health Check
# ============================================================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "THEOS AI Backend",
        "version": "2.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
