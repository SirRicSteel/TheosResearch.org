import './THEOSVisualizer.css'

function THEOSVisualizer({ reasoning }) {
  const { cycle, leftEngine, rightEngine, ceoEngine, quality, convergence } = reasoning

  return (
    <div className="theos-visualizer">
      <div className="visualizer-header">
        <h4>THEOS Reasoning Process</h4>
        <div className="cycle-counter">Cycle {cycle}</div>
      </div>

      <div className="engines-container">
        {/* CEO Engine - Top Center */}
        <div className="engine ceo-engine">
          <div className="engine-circle pulsing">
            <span className="engine-label">CEO</span>
          </div>
          <div className="engine-status">{ceoEngine}</div>
          <div className="arrows-down">
            <div className="arrow left-arrow">↓</div>
            <div className="arrow right-arrow">↓</div>
          </div>
        </div>

        {/* Left and Right Engines - Bottom */}
        <div className="bottom-engines">
          <div className="engine left-engine">
            <div className="engine-circle rotating-ccw pulsing">
              <span className="engine-label">L</span>
              <div className="rotation-indicator">↺</div>
            </div>
            <div className="engine-status">{leftEngine}</div>
          </div>

          <div className="engine right-engine">
            <div className="engine-circle rotating-ccw pulsing">
              <span className="engine-label">R</span>
              <div className="rotation-indicator">↻</div>
            </div>
            <div className="engine-status">{rightEngine}</div>
          </div>
        </div>
      </div>

      <div className="metrics">
        <div className="metric">
          <span className="metric-label">Quality</span>
          <div className="metric-bar">
            <div 
              className="metric-fill quality" 
              style={{width: `${(quality / 10) * 100}%`}}
            ></div>
          </div>
          <span className="metric-value">{quality.toFixed(1)}/10</span>
        </div>

        <div className="metric">
          <span className="metric-label">Convergence</span>
          <div className="metric-bar">
            <div 
              className="metric-fill convergence" 
              style={{width: `${convergence}%`}}
            ></div>
          </div>
          <span className="metric-value">{convergence}%</span>
        </div>
      </div>
    </div>
  )
}

export default THEOSVisualizer
