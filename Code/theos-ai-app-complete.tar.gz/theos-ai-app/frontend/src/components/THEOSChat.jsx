import { useState, useRef, useEffect } from 'react'
import { Link } from 'react-router-dom'
import THEOSVisualizer from './THEOSVisualizer'
import './THEOSChat.css'

function THEOSChat({ user, apiUrl }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [reasoning, setReasoning] = useState(null)
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!input.trim() || isProcessing) return

    const question = input.trim()
    setInput('')

    // Add user message
    setMessages(prev => [...prev, { role: 'user', content: question }])
    setIsProcessing(true)

    // Simulate THEOS reasoning process
    // In production, this would connect to the backend WebSocket
    simulateTHEOSReasoning(question)
  }

  const simulateTHEOSReasoning = async (question) => {
    // Simulate CEO Engine assessment
    setReasoning({
      cycle: 1,
      leftEngine: 'Analyzing patterns...',
      rightEngine: 'Identifying assumptions...',
      ceoEngine: 'Assessing complexity...',
      quality: 0,
      convergence: 0
    })

    // Simulate reasoning cycles
    for (let cycle = 1; cycle <= 3; cycle++) {
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      setReasoning({
        cycle,
        leftEngine: cycle === 1 ? 'Building hypothesis...' : cycle === 2 ? 'Refining theory...' : 'Validating conclusions...',
        rightEngine: cycle === 1 ? 'Challenging assumptions...' : cycle === 2 ? 'Testing edge cases...' : 'Final verification...',
        ceoEngine: `Monitoring quality... (Cycle ${cycle})`,
        quality: 3 + (cycle * 2),
        convergence: cycle * 30
      })
    }

    // Final answer
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    const answer = `Based on THEOS three-engine analysis:

**Left Engine (Constructive):** Identified key patterns and built a comprehensive hypothesis through inductive reasoning.

**Right Engine (Deconstructive):** Challenged assumptions and tested edge cases to ensure robustness.

**CEO Engine (Meta-Awareness):** Monitored reasoning quality across 3 cycles, achieving 85% convergence.

**Answer:** ${question.includes('?') ? 'This is a complex question that requires multi-faceted analysis. The THEOS methodology suggests...' : 'Based on the triadic reasoning process...'}

*Quality Score: 9.0/10*
*Convergence: 85%*`

    setMessages(prev => [...prev, { role: 'assistant', content: answer }])
    setReasoning(null)
    setIsProcessing(false)
  }

  return (
    <div className="theos-chat-container">
      <nav className="chat-nav">
        <Link to="/dashboard" className="back-link">← Dashboard</Link>
        <h2>THEOS Reasoning</h2>
        <div className="user-info">{user.email}</div>
      </nav>

      <div className="chat-layout">
        <div className="chat-messages">
          {messages.length === 0 && (
            <div className="empty-state">
              <h3>Ask THEOS Anything</h3>
              <p>Experience advanced AI reasoning with our three-engine architecture</p>
            </div>
          )}

          {messages.map((msg, idx) => (
            <div key={idx} className={`message ${msg.role}`}>
              <div className="message-content">
                {msg.content}
              </div>
            </div>
          ))}

          {isProcessing && reasoning && (
            <div className="message assistant processing">
              <div className="message-content">
                <THEOSVisualizer reasoning={reasoning} />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSubmit} className="chat-input-form">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a question..."
            disabled={isProcessing}
          />
          <button type="submit" className="primary" disabled={isProcessing || !input.trim()}>
            {isProcessing ? 'Processing...' : 'Ask'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default THEOSChat
