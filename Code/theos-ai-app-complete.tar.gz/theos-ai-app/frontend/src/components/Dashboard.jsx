import { Link } from 'react-router-dom'
import './Dashboard.css'

function Dashboard({ user, onLogout }) {
  return (
    <div className="dashboard-container">
      <nav className="dashboard-nav">
        <div className="nav-brand">
          <h2>THEOS AI</h2>
        </div>
        <div className="nav-user">
          <span>{user.full_name || user.email}</span>
          <button onClick={onLogout} className="secondary">Logout</button>
        </div>
      </nav>

      <div className="dashboard-content">
        <div className="welcome-section">
          <h1>Welcome to THEOS AI</h1>
          <p>Advanced AI Reasoning with Three-Engine Architecture</p>
        </div>

        <div className="stats-grid">
          <div className="stat-card card">
            <h3>Subscription</h3>
            <p className="stat-value">{user.subscription_tier}</p>
            <p className="stat-label">Current Plan</p>
          </div>

          <div className="stat-card card">
            <h3>Today's Usage</h3>
            <p className="stat-value">{user.queries_used_today}/10</p>
            <p className="stat-label">Questions Asked</p>
          </div>

          <div className="stat-card card">
            <h3>Total Questions</h3>
            <p className="stat-value">{user.total_queries}</p>
            <p className="stat-label">All Time</p>
          </div>
        </div>

        <div className="action-section">
          <Link to="/chat" className="cta-button">
            <button className="primary large">
              Start Reasoning Session
            </button>
          </Link>
        </div>

        <div className="features-section">
          <h2>How THEOS Works</h2>
          <div className="features-grid">
            <div className="feature-card card">
              <div className="feature-icon" style={{background: 'linear-gradient(135deg, #4A90E2, #357ABD)'}}>
                <span>L</span>
              </div>
              <h3>Left Engine</h3>
              <p>Constructive reasoning - builds hypotheses using inductive, abductive, and deductive logic.</p>
            </div>

            <div className="feature-card card">
              <div className="feature-icon" style={{background: 'linear-gradient(135deg, #E67E22, #D35400)'}}>
                <span>R</span>
              </div>
              <h3>Right Engine</h3>
              <p>Deconstructive reasoning - challenges assumptions and identifies potential flaws.</p>
            </div>

            <div className="feature-card card">
              <div className="feature-icon" style={{background: 'linear-gradient(135deg, #9B59B6, #8E44AD)'}}>
                <span>C</span>
              </div>
              <h3>CEO Engine</h3>
              <p>Meta-awareness - monitors quality, detects convergence, and synthesizes final answers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
