"""
THEOS Plugin - Setup Configuration
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="theos-plugin",
    version="1.0.0",
    author="Frederick Davis Stalnecker",
    author_email="guestent@gmail.com",
    description="THEOS - Triadic reasoning plugin for transformer models with 50-65% energy savings",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/theos-plugin",
    packages=find_packages(exclude=["tests", "tests.*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "transformers>=4.20.0",
        "torch>=1.10.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
        ],
    },
    keywords="ai transformer reasoning triadic philosophy energy-efficient llm",
    license="MIT",
    project_urls={
        "Documentation": "https://github.com/yourusername/theos-plugin",
        "Source": "https://github.com/yourusername/theos-plugin",
        "Tracker": "https://github.com/yourusername/theos-plugin/issues",
    },
)
