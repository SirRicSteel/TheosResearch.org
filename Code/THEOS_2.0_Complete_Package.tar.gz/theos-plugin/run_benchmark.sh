#!/bin/bash
#
# THEOS Quick Benchmark Script
# =============================
#
# Runs a complete benchmark and generates analysis report
#
# Usage:
#   ./run_benchmark.sh              # Quick test with distilgpt2
#   ./run_benchmark.sh --full       # Full benchmark
#   ./run_benchmark.sh --model gpt2 # Specific model
#

set -e  # Exit on error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}================================${NC}"
echo -e "${BLUE}THEOS BENCHMARK QUICK START${NC}"
echo -e "${BLUE}================================${NC}"
echo

# Parse arguments
MODEL="distilgpt2"
QUICK_TEST="--quick-test"

while [[ $# -gt 0 ]]; do
    case $1 in
        --full)
            QUICK_TEST=""
            shift
            ;;
        --model)
            MODEL="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--full] [--model MODEL_NAME]"
            exit 1
            ;;
    esac
done

# Check dependencies
echo -e "${YELLOW}Checking dependencies...${NC}"

if ! python3 -c "import transformers" 2>/dev/null; then
    echo "ERROR: transformers not installed"
    echo "Install with: pip install transformers torch"
    exit 1
fi

if ! python3 -c "import torch" 2>/dev/null; then
    echo "ERROR: torch not installed"
    echo "Install with: pip install torch"
    exit 1
fi

echo -e "${GREEN}✓ Dependencies OK${NC}"
echo

# Run benchmark
echo -e "${YELLOW}Running benchmark...${NC}"
echo "Model: $MODEL"
echo "Mode: $([ -z "$QUICK_TEST" ] && echo "Full" || echo "Quick Test")"
echo

python3 benchmark_suite.py --model "$MODEL" $QUICK_TEST

if [ $? -ne 0 ]; then
    echo -e "${YELLOW}Benchmark failed!${NC}"
    exit 1
fi

echo
echo -e "${GREEN}✓ Benchmark complete${NC}"
echo

# Find latest result file
LATEST_RESULT=$(ls -t benchmark_results/benchmark_*.json 2>/dev/null | head -1)

if [ -z "$LATEST_RESULT" ]; then
    echo -e "${YELLOW}No result files found${NC}"
    exit 1
fi

echo -e "${YELLOW}Analyzing results...${NC}"
echo

# Run analysis
python3 analyze_results.py "$LATEST_RESULT"

if [ $? -ne 0 ]; then
    echo -e "${YELLOW}Analysis failed!${NC}"
    exit 1
fi

echo
echo -e "${GREEN}✓ Analysis complete${NC}"
echo

# Find latest report
LATEST_REPORT=$(ls -t benchmark_results/BENCHMARK_REPORT_*.md 2>/dev/null | head -1)

echo -e "${BLUE}================================${NC}"
echo -e "${GREEN}✅ BENCHMARK COMPLETE!${NC}"
echo -e "${BLUE}================================${NC}"
echo
echo "Results:"
echo "  - Raw data: $LATEST_RESULT"
echo "  - Report:   $LATEST_REPORT"
echo "  - Charts:   benchmark_results/*.png"
echo
echo "Next steps:"
echo "  1. Review the report: cat $LATEST_REPORT"
echo "  2. View the charts (if matplotlib installed)"
echo "  3. Share results with stakeholders"
echo
echo -e "${BLUE}================================${NC}"
