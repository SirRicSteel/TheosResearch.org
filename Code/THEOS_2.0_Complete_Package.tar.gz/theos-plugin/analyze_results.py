#!/usr/bin/env python3
"""
THEOS Benchmark Results Analyzer
=================================

Analyzes benchmark results from benchmark_suite.py and generates:
- Statistical summaries
- Visualization charts
- Publication-ready tables
- Markdown report

Usage:
    python analyze_results.py benchmark_results/benchmark_distilgpt2_*.json
    python analyze_results.py benchmark_results/*.json --output report.md
    python analyze_results.py --help
"""

import argparse
import json
import os
import sys
from typing import Dict, List, Any
from datetime import datetime
import glob

# Optional visualization dependencies
try:
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    print("Warning: matplotlib not installed. Visualizations will be skipped.")
    print("Install with: pip install matplotlib")


class BenchmarkAnalyzer:
    """Analyzes THEOS benchmark results and generates reports."""
    
    def __init__(self, result_files: List[str]):
        """
        Initialize analyzer with benchmark result files.
        
        Args:
            result_files: List of JSON result file paths
        """
        self.result_files = result_files
        self.results = []
        
        print(f"Loading {len(result_files)} result file(s)...")
        for filepath in result_files:
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    self.results.append(data)
                    print(f"✓ Loaded: {os.path.basename(filepath)}")
            except Exception as e:
                print(f"✗ Failed to load {filepath}: {e}")
        
        if not self.results:
            print("ERROR: No valid result files loaded")
            sys.exit(1)
        
        print(f"\n{len(self.results)} result file(s) loaded successfully\n")
    
    def extract_energy_efficiency_data(self) -> Dict[str, Any]:
        """Extract energy efficiency metrics from results."""
        efficiency_data = []
        
        for result in self.results:
            for benchmark in result.get("benchmarks", []):
                if benchmark.get("test") == "energy_efficiency":
                    efficiency_data.append({
                        "model": result["metadata"]["model_name"],
                        "time_reduction": benchmark["comparison"]["time_reduction_percent"],
                        "token_reduction": benchmark["comparison"]["token_reduction_percent"],
                        "efficiency_gain": benchmark["comparison"]["efficiency_gain"],
                        "baseline_time": benchmark["baseline"]["total_time"],
                        "theos_time": benchmark["theos"]["total_time"],
                        "baseline_tokens": benchmark["baseline"]["total_tokens"],
                        "theos_tokens": benchmark["theos"]["total_tokens"],
                        "avg_cycles": benchmark["theos"]["avg_cycles_per_prompt"],
                    })
        
        return efficiency_data
    
    def extract_cache_performance_data(self) -> Dict[str, Any]:
        """Extract cache performance metrics from results."""
        cache_data = []
        
        for result in self.results:
            for benchmark in result.get("benchmarks", []):
                if benchmark.get("test") == "cache_performance":
                    cache_data.append({
                        "model": result["metadata"]["model_name"],
                        "hit_rate": benchmark["hit_rate"] * 100,
                        "speedup_factor": benchmark["speedup_factor"],
                        "avg_first_run": benchmark["avg_first_run_time"],
                        "avg_second_run": benchmark["avg_second_run_time"],
                    })
        
        return cache_data
    
    def extract_convergence_data(self) -> Dict[str, Any]:
        """Extract convergence analysis data from results."""
        convergence_data = []
        
        for result in self.results:
            for benchmark in result.get("benchmarks", []):
                if benchmark.get("test") == "convergence_analysis":
                    for conv_result in benchmark["results"]:
                        convergence_data.append({
                            "model": result["metadata"]["model_name"],
                            "max_cycles": conv_result["max_cycles"],
                            "convergence_rate": conv_result["convergence_rate"] * 100,
                            "avg_cycles_used": conv_result["avg_cycles_used"],
                        })
        
        return convergence_data
    
    def generate_summary_statistics(self) -> str:
        """Generate summary statistics as formatted text."""
        output = []
        output.append("=" * 70)
        output.append("THEOS BENCHMARK RESULTS - SUMMARY STATISTICS")
        output.append("=" * 70)
        output.append("")
        
        # Energy Efficiency Summary
        efficiency_data = self.extract_energy_efficiency_data()
        if efficiency_data:
            output.append("ENERGY EFFICIENCY")
            output.append("-" * 70)
            for data in efficiency_data:
                output.append(f"Model: {data['model']}")
                output.append(f"  Time Reduction:       {data['time_reduction']:6.2f}%")
                output.append(f"  Token Reduction:      {data['token_reduction']:6.2f}%")
                output.append(f"  Efficiency Gain:      {data['efficiency_gain']:6.2f}%")
                output.append(f"  Avg Cycles per Query: {data['avg_cycles']:6.2f}")
                output.append("")
        
        # Cache Performance Summary
        cache_data = self.extract_cache_performance_data()
        if cache_data:
            output.append("CACHE PERFORMANCE")
            output.append("-" * 70)
            for data in cache_data:
                output.append(f"Model: {data['model']}")
                output.append(f"  Cache Hit Rate:       {data['hit_rate']:6.2f}%")
                output.append(f"  Speedup Factor:       {data['speedup_factor']:6.2f}x")
                output.append(f"  First Run Time:       {data['avg_first_run']:6.3f}s")
                output.append(f"  Cached Run Time:      {data['avg_second_run']:6.3f}s")
                output.append("")
        
        # Convergence Summary
        convergence_data = self.extract_convergence_data()
        if convergence_data:
            output.append("CONVERGENCE ANALYSIS")
            output.append("-" * 70)
            
            # Group by model
            models = set(d['model'] for d in convergence_data)
            for model in models:
                output.append(f"Model: {model}")
                model_data = [d for d in convergence_data if d['model'] == model]
                for data in sorted(model_data, key=lambda x: x['max_cycles']):
                    output.append(f"  Max Cycles: {data['max_cycles']:2d} | "
                                f"Convergence Rate: {data['convergence_rate']:5.1f}% | "
                                f"Avg Cycles Used: {data['avg_cycles_used']:4.1f}")
                output.append("")
        
        output.append("=" * 70)
        
        return "\n".join(output)
    
    def generate_markdown_table(self, data: List[Dict], columns: List[str], title: str) -> str:
        """Generate a markdown table from data."""
        if not data:
            return ""
        
        output = [f"\n### {title}\n"]
        
        # Header
        header = "| " + " | ".join(columns) + " |"
        separator = "|" + "|".join([" --- " for _ in columns]) + "|"
        output.append(header)
        output.append(separator)
        
        # Rows
        for row in data:
            values = []
            for col in columns:
                val = row.get(col.lower().replace(" ", "_"), "N/A")
                if isinstance(val, float):
                    values.append(f"{val:.2f}")
                else:
                    values.append(str(val))
            output.append("| " + " | ".join(values) + " |")
        
        return "\n".join(output)
    
    def generate_markdown_report(self) -> str:
        """Generate complete markdown report."""
        output = []
        
        # Header
        output.append("# THEOS Benchmark Report")
        output.append("")
        output.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        output.append("")
        output.append("---")
        output.append("")
        
        # Executive Summary
        output.append("## Executive Summary")
        output.append("")
        
        efficiency_data = self.extract_energy_efficiency_data()
        if efficiency_data:
            avg_time_reduction = sum(d['time_reduction'] for d in efficiency_data) / len(efficiency_data)
            avg_token_reduction = sum(d['token_reduction'] for d in efficiency_data) / len(efficiency_data)
            
            output.append(f"**THEOS achieves {avg_time_reduction:.1f}% reduction in inference time "
                        f"and {avg_token_reduction:.1f}% reduction in token usage** compared to "
                        f"standard transformer inference.")
            output.append("")
        
        cache_data = self.extract_cache_performance_data()
        if cache_data:
            avg_hit_rate = sum(d['hit_rate'] for d in cache_data) / len(cache_data)
            avg_speedup = sum(d['speedup_factor'] for d in cache_data) / len(cache_data)
            
            output.append(f"**WisdomCache achieves {avg_hit_rate:.1f}% hit rate** on repeated queries, "
                        f"providing **{avg_speedup:.1f}x speedup** for cached responses.")
            output.append("")
        
        output.append("---")
        output.append("")
        
        # Energy Efficiency Results
        if efficiency_data:
            output.append("## Energy Efficiency Results")
            output.append("")
            output.append("Comparison of THEOS vs. baseline transformer inference:")
            output.append("")
            
            table_data = []
            for data in efficiency_data:
                table_data.append({
                    "Model": data['model'],
                    "Time Reduction (%)": data['time_reduction'],
                    "Token Reduction (%)": data['token_reduction'],
                    "Avg Cycles": data['avg_cycles'],
                })
            
            output.append(self.generate_markdown_table(
                table_data,
                ["Model", "Time Reduction (%)", "Token Reduction (%)", "Avg Cycles"],
                "Performance Comparison"
            ))
            output.append("")
        
        # Cache Performance Results
        if cache_data:
            output.append("## Cache Performance Results")
            output.append("")
            output.append("WisdomCache performance on repeated queries:")
            output.append("")
            
            table_data = []
            for data in cache_data:
                table_data.append({
                    "Model": data['model'],
                    "Hit Rate (%)": data['hit_rate'],
                    "Speedup Factor": data['speedup_factor'],
                    "First Run (s)": data['avg_first_run'],
                    "Cached Run (s)": data['avg_second_run'],
                })
            
            output.append(self.generate_markdown_table(
                table_data,
                ["Model", "Hit Rate (%)", "Speedup Factor", "First Run (s)", "Cached Run (s)"],
                "Cache Statistics"
            ))
            output.append("")
        
        # Convergence Analysis
        convergence_data = self.extract_convergence_data()
        if convergence_data:
            output.append("## Convergence Analysis")
            output.append("")
            output.append("Convergence behavior across different cycle limits:")
            output.append("")
            
            table_data = []
            for data in convergence_data:
                table_data.append({
                    "Model": data['model'],
                    "Max Cycles": data['max_cycles'],
                    "Convergence Rate (%)": data['convergence_rate'],
                    "Avg Cycles Used": data['avg_cycles_used'],
                })
            
            output.append(self.generate_markdown_table(
                table_data,
                ["Model", "Max Cycles", "Convergence Rate (%)", "Avg Cycles Used"],
                "Convergence Statistics"
            ))
            output.append("")
        
        # Methodology
        output.append("---")
        output.append("")
        output.append("## Methodology")
        output.append("")
        output.append("### Test Setup")
        output.append("")
        
        if self.results:
            metadata = self.results[0]["metadata"]
            output.append(f"- **Model:** {metadata['model_name']}")
            output.append(f"- **PyTorch Version:** {metadata.get('torch_version', 'N/A')}")
            output.append(f"- **Python Version:** {metadata.get('python_version', 'N/A')}")
            output.append("")
        
        output.append("### Benchmarks")
        output.append("")
        output.append("1. **Energy Efficiency:** Compares total inference time and token usage between "
                    "baseline transformer inference and THEOS triadic reasoning.")
        output.append("")
        output.append("2. **Cache Performance:** Measures WisdomCache hit rates and speedup on repeated queries.")
        output.append("")
        output.append("3. **Convergence Analysis:** Evaluates convergence behavior across different cycle limits.")
        output.append("")
        
        # Conclusions
        output.append("---")
        output.append("")
        output.append("## Conclusions")
        output.append("")
        
        if efficiency_data:
            avg_reduction = sum(d['time_reduction'] for d in efficiency_data) / len(efficiency_data)
            output.append(f"THEOS demonstrates **{avg_reduction:.1f}% average reduction** in computational "
                        f"requirements compared to standard transformer inference, validating the energy "
                        f"efficiency claims of triadic reasoning.")
            output.append("")
        
        if cache_data:
            output.append("The WisdomCache component provides significant performance gains on repeated "
                        "queries, making THEOS particularly effective for production deployments with "
                        "common query patterns.")
            output.append("")
        
        output.append("These results demonstrate that **THEOS provides a practical, deployable framework "
                    "for more efficient AI reasoning** without requiring model retraining or architecture changes.")
        output.append("")
        
        return "\n".join(output)
    
    def create_visualizations(self, output_dir: str = "benchmark_results"):
        """Create visualization charts from benchmark data."""
        if not HAS_MATPLOTLIB:
            print("Skipping visualizations (matplotlib not installed)")
            return
        
        os.makedirs(output_dir, exist_ok=True)
        
        # 1. Energy Efficiency Chart
        efficiency_data = self.extract_energy_efficiency_data()
        if efficiency_data:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
            
            models = [d['model'] for d in efficiency_data]
            time_reductions = [d['time_reduction'] for d in efficiency_data]
            token_reductions = [d['token_reduction'] for d in efficiency_data]
            
            ax1.bar(models, time_reductions, color='#2ecc71')
            ax1.set_ylabel('Time Reduction (%)')
            ax1.set_title('THEOS Time Reduction vs. Baseline')
            ax1.set_ylim(0, 100)
            ax1.grid(axis='y', alpha=0.3)
            
            ax2.bar(models, token_reductions, color='#3498db')
            ax2.set_ylabel('Token Reduction (%)')
            ax2.set_title('THEOS Token Reduction vs. Baseline')
            ax2.set_ylim(0, 100)
            ax2.grid(axis='y', alpha=0.3)
            
            plt.tight_layout()
            chart_path = os.path.join(output_dir, 'energy_efficiency.png')
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"✓ Created: {chart_path}")
        
        # 2. Cache Performance Chart
        cache_data = self.extract_cache_performance_data()
        if cache_data:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
            
            models = [d['model'] for d in cache_data]
            hit_rates = [d['hit_rate'] for d in cache_data]
            speedups = [d['speedup_factor'] for d in cache_data]
            
            ax1.bar(models, hit_rates, color='#9b59b6')
            ax1.set_ylabel('Hit Rate (%)')
            ax1.set_title('WisdomCache Hit Rate')
            ax1.set_ylim(0, 100)
            ax1.grid(axis='y', alpha=0.3)
            
            ax2.bar(models, speedups, color='#e74c3c')
            ax2.set_ylabel('Speedup Factor')
            ax2.set_title('Cache Speedup on Repeated Queries')
            ax2.grid(axis='y', alpha=0.3)
            
            plt.tight_layout()
            chart_path = os.path.join(output_dir, 'cache_performance.png')
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"✓ Created: {chart_path}")
        
        # 3. Convergence Analysis Chart
        convergence_data = self.extract_convergence_data()
        if convergence_data:
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # Group by model
            models = set(d['model'] for d in convergence_data)
            for model in models:
                model_data = [d for d in convergence_data if d['model'] == model]
                model_data.sort(key=lambda x: x['max_cycles'])
                
                max_cycles = [d['max_cycles'] for d in model_data]
                conv_rates = [d['convergence_rate'] for d in model_data]
                
                ax.plot(max_cycles, conv_rates, marker='o', label=model, linewidth=2)
            
            ax.set_xlabel('Maximum Cycles Allowed')
            ax.set_ylabel('Convergence Rate (%)')
            ax.set_title('Convergence Rate vs. Cycle Limit')
            ax.legend()
            ax.grid(alpha=0.3)
            ax.set_ylim(0, 100)
            
            plt.tight_layout()
            chart_path = os.path.join(output_dir, 'convergence_analysis.png')
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"✓ Created: {chart_path}")
    
    def generate_full_report(self, output_file: str = None, create_charts: bool = True):
        """Generate complete analysis report."""
        print("=" * 70)
        print("ANALYZING BENCHMARK RESULTS")
        print("=" * 70)
        print()
        
        # Print summary statistics
        summary = self.generate_summary_statistics()
        print(summary)
        print()
        
        # Generate markdown report
        print("Generating markdown report...")
        markdown_report = self.generate_markdown_report()
        
        if output_file is None:
            output_file = f"benchmark_results/BENCHMARK_REPORT_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        with open(output_file, 'w') as f:
            f.write(markdown_report)
        
        print(f"✓ Report saved to: {output_file}")
        print()
        
        # Create visualizations
        if create_charts:
            print("Creating visualizations...")
            self.create_visualizations(os.path.dirname(output_file) or "benchmark_results")
            print()
        
        print("=" * 70)
        print("✅ ANALYSIS COMPLETE")
        print("=" * 70)


def main():
    parser = argparse.ArgumentParser(
        description="Analyze THEOS benchmark results and generate reports"
    )
    parser.add_argument(
        "files",
        nargs="+",
        help="Benchmark result JSON files (supports wildcards)"
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output markdown report file (default: auto-generated)"
    )
    parser.add_argument(
        "--no-charts",
        action="store_true",
        help="Skip chart generation"
    )
    
    args = parser.parse_args()
    
    # Expand wildcards
    result_files = []
    for pattern in args.files:
        matches = glob.glob(pattern)
        if matches:
            result_files.extend(matches)
        else:
            result_files.append(pattern)  # Try as literal path
    
    if not result_files:
        print("ERROR: No result files specified")
        sys.exit(1)
    
    try:
        analyzer = BenchmarkAnalyzer(result_files)
        analyzer.generate_full_report(
            output_file=args.output,
            create_charts=not args.no_charts
        )
    except KeyboardInterrupt:
        print("\n\nAnalysis interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nAnalysis failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
