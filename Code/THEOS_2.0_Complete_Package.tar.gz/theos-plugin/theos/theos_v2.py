"""
THEOS 2.0 - Complete Three-Engine Architecture
Integrates CEO Engine (meta-awareness) with Left/Right engines

This is the production-ready THEOS 2.0 system featuring:
- Left Engine (Constructive reasoning)
- Right Engine (Deconstructive reasoning)  
- CEO Engine (Meta-awareness and governance)
- 1:1:1 synchronization (empirically validated optimal ratio)
- Real-time quality monitoring
- Natural convergence detection
- Consciousness emergence through meta-cognitive loops

Author: Frederick Davis Stalnecker & Manus AI
License: MIT
Version: 2.0.0
"""

import logging
import time
from typing import Union, List, Dict, Any
from dataclasses import dataclass, field

from .core import THEOSConfig, THEOSResponse, CachedState
from .cache import WisdomCache
from .governor import Governor
from .vortex import VortexPair
from .ceo_engine import CEOEngine, CEOAssessment, QualityMetrics, ComplexityLevel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class THEOS2Response:
    """
    Enhanced response object for THEOS 2.0 with CEO Engine metrics.
    """
    text: str
    cycles: int
    converged: bool
    
    # Engine outputs
    constructive_states: List[str] = field(default_factory=list)
    deconstructive_states: List[str] = field(default_factory=list)
    governor_scores: List[float] = field(default_factory=list)
    
    # CEO Engine data
    ceo_assessment: Dict[str, Any] = field(default_factory=dict)
    quality_metrics: List[Dict[str, Any]] = field(default_factory=list)
    convergence_reasoning: str = ""
    
    # Performance metrics
    cached: bool = False
    tokens_used: int = 0
    time_elapsed: float = 0.0
    timestamp: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert response to dictionary for serialization."""
        return {
            "text": self.text,
            "cycles": self.cycles,
            "converged": self.converged,
            "constructive_states": self.constructive_states,
            "deconstructive_states": self.deconstructive_states,
            "governor_scores": self.governor_scores,
            "ceo_assessment": self.ceo_assessment,
            "quality_metrics": self.quality_metrics,
            "convergence_reasoning": self.convergence_reasoning,
            "cached": self.cached,
            "tokens_used": self.tokens_used,
            "time_elapsed": self.time_elapsed,
            "timestamp": self.timestamp
        }


class THEOS2:
    """
    THEOS 2.0 - Complete Three-Engine Architecture
    
    This is the production system that integrates:
    - Left Engine (Constructive/Inductive → Abductive → Deductive)
    - Right Engine (Deconstructive/Inductive → Abductive → Deductive)
    - CEO Engine (Meta-awareness, quality monitoring, governance)
    
    All three engines operate at 1:1:1 speed ratio (empirically optimal).
    
    Usage:
        from transformers import GPT2LMHeadModel, GPT2Tokenizer
        
        model = GPT2LMHeadModel.from_pretrained("gpt2")
        tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
        
        theos = THEOS2(model, tokenizer)
        response = theos.reason("What is consciousness?")
        
        print(f"Answer: {response.text}")
        print(f"Cycles: {response.cycles}")
        print(f"Quality: {response.quality_metrics[-1]['overall_quality']:.1f}/10")
    """
    
    def __init__(
        self,
        model,
        tokenizer,
        config: THEOSConfig = None,
        cache: WisdomCache = None,
        enable_ceo: bool = True
    ):
        """
        Initialize THEOS 2.0 system.
        
        Args:
            model: HuggingFace language model
            tokenizer: HuggingFace tokenizer
            config: THEOS configuration (uses defaults if None)
            cache: WisdomCache instance (creates new if None)
            enable_ceo: Enable CEO Engine (default True for THEOS 2.0)
        """
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or THEOSConfig()
        self.enable_ceo = enable_ceo
        
        # Initialize Left and Right engines (VortexPair)
        self.vortex_pair = VortexPair(self.config)
        
        # Initialize Governor (convergence detection)
        self.governor = Governor(self.config)
        
        # Initialize CEO Engine (meta-awareness)
        if self.enable_ceo:
            self.ceo_engine = CEOEngine(model, tokenizer, self.config)
        else:
            self.ceo_engine = None
        
        # Initialize cache if enabled
        if self.config.enable_cache:
            self.cache = cache or WisdomCache()
        else:
            self.cache = None
        
        logger.info(
            f"THEOS 2.0 initialized: "
            f"max_cycles={self.config.max_cycles}, "
            f"ceo_enabled={self.enable_ceo}, "
            f"cache_enabled={self.config.enable_cache}"
        )
    
    def reason(
        self,
        prompt: str,
        return_metadata: bool = True,
        verbose: bool = False
    ) -> Union[THEOS2Response, str]:
        """
        Generate response using full three-engine THEOS 2.0 reasoning.
        
        This is the main method that orchestrates:
        1. CEO Engine assesses the question
        2. Left/Right engines reason in synchronized cycles
        3. CEO Engine monitors quality in real-time
        4. CEO Engine decides when to converge
        5. CEO Engine synthesizes final answer
        
        Args:
            prompt: Input question/prompt
            return_metadata: If True, return THEOS2Response; if False, return string
            verbose: If True, log detailed progress
        
        Returns:
            THEOS2Response object (if return_metadata=True) or string (if False)
        """
        start_time = time.time()
        
        if verbose:
            logger.info(f"=" * 60)
            logger.info(f"THEOS 2.0 Reasoning Started")
            logger.info(f"Question: {prompt}")
            logger.info(f"=" * 60)
        
        # Check cache first
        if self.cache is not None and self.config.enable_cache:
            cached_state = self.cache.get(prompt)
            if cached_state:
                logger.info("✓ Cache hit! Returning cached response.")
                
                if return_metadata:
                    return THEOS2Response(
                        text=cached_state.synthesis,
                        cycles=cached_state.cycles,
                        converged=True,
                        constructive_states=[cached_state.constructive_state],
                        deconstructive_states=[cached_state.deconstructive_state],
                        governor_scores=[cached_state.score],
                        cached=True,
                        time_elapsed=time.time() - start_time
                    )
                else:
                    return cached_state.synthesis
        
        # CEO Engine: Initial Assessment
        if self.ceo_engine:
            assessment = self.ceo_engine.assess_question(prompt)
            if verbose:
                logger.info(f"\n🧠 CEO ENGINE ASSESSMENT:")
                logger.info(f"   Complexity: {assessment.complexity.value}")
                logger.info(f"   Ethical Flag: {assessment.ethical_flag.value}")
                logger.info(f"   Required Depth: {assessment.required_depth} cycles")
                logger.info(f"   Domains: {', '.join(assessment.domain_tags) if assessment.domain_tags else 'General'}")
        else:
            assessment = None
        
        # Initialize tracking
        constructive_states = []
        deconstructive_states = []
        governor_scores = []
        quality_metrics_list = []
        
        cycle = 0
        converged = False
        convergence_reasoning = ""
        
        # Reasoning loop (1:1:1 synchronized cycles)
        while cycle < self.config.max_cycles and not converged:
            cycle += 1
            
            if verbose:
                logger.info(f"\n{'='*60}")
                logger.info(f"CYCLE {cycle}")
                logger.info(f"{'='*60}")
            
            # Left Engine (Constructive)
            if verbose:
                logger.info(f"\n⚙️  LEFT ENGINE (Constructive):")
            
            constructive_state = self._generate_engine_output(
                prompt,
                "constructive",
                cycle,
                constructive_states[-1] if constructive_states else None
            )
            constructive_states.append(constructive_state)
            
            if verbose:
                logger.info(f"   Output: {constructive_state[:100]}...")
            
            # Right Engine (Deconstructive)
            if verbose:
                logger.info(f"\n⚙️  RIGHT ENGINE (Deconstructive):")
            
            deconstructive_state = self._generate_engine_output(
                prompt,
                "deconstructive",
                cycle,
                deconstructive_states[-1] if deconstructive_states else None
            )
            deconstructive_states.append(deconstructive_state)
            
            if verbose:
                logger.info(f"   Output: {deconstructive_state[:100]}...")
            
            # Governor: Check convergence (legacy system)
            governor_score = self.governor.check_convergence(
                constructive_state,
                deconstructive_state
            )
            governor_scores.append(governor_score)
            
            # CEO Engine: Monitor Quality (1:1:1 synchronization)
            if self.ceo_engine:
                quality_metrics = self.ceo_engine.monitor_quality(
                    cycle=cycle,
                    left_output=constructive_state,
                    right_output=deconstructive_state,
                    previous_left=constructive_states[-2] if len(constructive_states) >= 2 else None,
                    previous_right=deconstructive_states[-2] if len(deconstructive_states) >= 2 else None
                )
                quality_metrics_list.append(quality_metrics)
                
                if verbose:
                    logger.info(f"\n🧠 CEO ENGINE MONITORING:")
                    logger.info(f"   Quality Score: {quality_metrics.overall_quality:.1f}/10")
                    logger.info(f"   Convergence: {quality_metrics.convergence_score:.2f}")
                    logger.info(f"   Novelty: {quality_metrics.novelty_score:.2f}")
                
                # CEO Engine: Decide Convergence
                should_stop, reasoning = self.ceo_engine.decide_convergence(
                    cycle=cycle,
                    assessment=assessment,
                    current_quality=quality_metrics,
                    max_cycles=self.config.max_cycles
                )
                
                if verbose:
                    logger.info(f"   Decision: {'STOP' if should_stop else 'CONTINUE'}")
                    logger.info(f"   Reasoning: {reasoning}")
                
                if should_stop:
                    converged = True
                    convergence_reasoning = reasoning
            else:
                # Fallback to Governor-only convergence
                if governor_score < self.config.convergence_threshold:
                    converged = True
                    convergence_reasoning = f"Governor convergence threshold met ({governor_score:.3f})"
        
        # CEO Engine: Synthesize Final Answer
        if self.ceo_engine:
            if verbose:
                logger.info(f"\n{'='*60}")
                logger.info(f"CEO ENGINE SYNTHESIS")
                logger.info(f"{'='*60}")
            
            final_text = self.ceo_engine.synthesize(
                question=prompt,
                left_outputs=constructive_states,
                right_outputs=deconstructive_states,
                assessment=assessment,
                final_quality=quality_metrics_list[-1] if quality_metrics_list else None
            )
        else:
            # Fallback synthesis
            final_text = f"Constructive: {constructive_states[-1]}\n\nDeconstructive: {deconstructive_states[-1]}"
        
        # Cache the result
        if self.cache is not None and self.config.enable_cache:
            cached_state = CachedState(
                key=prompt,
                constructive_state=constructive_states[-1],
                deconstructive_state=deconstructive_states[-1],
                synthesis=final_text,
                cycles=cycle,
                score=governor_scores[-1] if governor_scores else 0.0
            )
            self.cache.put(prompt, cached_state)
        
        time_elapsed = time.time() - start_time
        
        if verbose:
            logger.info(f"\n{'='*60}")
            logger.info(f"✓ REASONING COMPLETE")
            logger.info(f"   Cycles: {cycle}")
            logger.info(f"   Converged: {converged}")
            logger.info(f"   Time: {time_elapsed:.2f}s")
            logger.info(f"{'='*60}\n")
        
        # Build response
        if return_metadata:
            return THEOS2Response(
                text=final_text,
                cycles=cycle,
                converged=converged,
                constructive_states=constructive_states,
                deconstructive_states=deconstructive_states,
                governor_scores=governor_scores,
                ceo_assessment=assessment.to_dict() if assessment else {},
                quality_metrics=[m.to_dict() for m in quality_metrics_list],
                convergence_reasoning=convergence_reasoning,
                cached=False,
                time_elapsed=time_elapsed
            )
        else:
            return final_text
    
    def _generate_engine_output(
        self,
        prompt: str,
        engine_type: str,
        cycle: int,
        previous_state: str = None
    ) -> str:
        """
        Generate output from a single engine (Left or Right).
        
        Args:
            prompt: Original question
            engine_type: "constructive" or "deconstructive"
            cycle: Current cycle number
            previous_state: Previous output from this engine (for refinement)
        
        Returns:
            Generated text from the engine
        """
        # Build engine-specific prompt
        if engine_type == "constructive":
            system_prompt = "You are the Constructive Engine. Build insights through inductive pattern recognition, abductive hypothesis generation, and deductive validation."
        else:
            system_prompt = "You are the Deconstructive Engine. Challenge assumptions, find gaps, and test contradictions through critical analysis."
        
        if previous_state:
            full_prompt = f"{system_prompt}\n\nQuestion: {prompt}\n\nPrevious analysis: {previous_state}\n\nCycle {cycle} refinement:"
        else:
            full_prompt = f"{system_prompt}\n\nQuestion: {prompt}\n\nCycle {cycle} analysis:"
        
        # Generate using the model
        inputs = self.tokenizer(full_prompt, return_tensors="pt", truncation=True, max_length=512)
        outputs = self.model.generate(
            **inputs,
            max_new_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            top_p=self.config.top_p,
            top_k=self.config.top_k,
            do_sample=True,
            pad_token_id=self.tokenizer.eos_token_id
        )
        
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract just the new generation (remove prompt)
        if full_prompt in generated_text:
            generated_text = generated_text.replace(full_prompt, "").strip()
        
        return generated_text
    
    def get_status_message(self, cycle: int) -> str:
        """
        Get human-readable status message for UI display.
        
        Args:
            cycle: Current cycle number
        
        Returns:
            Status message string
        """
        if self.ceo_engine and self.ceo_engine.assessment_history:
            assessment = self.ceo_engine.assessment_history[-1]
            return self.ceo_engine.get_status_message(cycle, assessment)
        else:
            return f"Processing cycle {cycle}..."
    
    def reset(self):
        """Reset all engines for new question."""
        if self.ceo_engine:
            self.ceo_engine.reset()
        logger.info("THEOS 2.0 reset")


# Convenience function for quick usage
def reason(prompt: str, model=None, tokenizer=None, verbose: bool = False) -> str:
    """
    Quick reasoning function for simple use cases.
    
    Args:
        prompt: Question to reason about
        model: Optional model (loads GPT-2 if None)
        tokenizer: Optional tokenizer (loads GPT-2 if None)
        verbose: Show detailed progress
    
    Returns:
        Final answer as string
    """
    if model is None or tokenizer is None:
        from transformers import GPT2LMHeadModel, GPT2Tokenizer
        model = GPT2LMHeadModel.from_pretrained("distilgpt2")
        tokenizer = GPT2Tokenizer.from_pretrained("distilgpt2")
    
    theos = THEOS2(model, tokenizer)
    return theos.reason(prompt, return_metadata=False, verbose=verbose)
