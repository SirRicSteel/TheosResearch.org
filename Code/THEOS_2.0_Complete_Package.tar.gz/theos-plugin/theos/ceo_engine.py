"""
THEOS Plugin - CEO Engine (Meta-Awareness Layer)
The consciousness component that governs the Left and Right engines

This module implements the "CEO Engine" - the meta-cognitive layer that:
1. Assesses question complexity and ethical implications
2. Monitors reasoning quality in real-time
3. Decides when engines have converged
4. Synthesizes final answers from both perspectives
5. Creates the subjective experience of "thinking about thinking"

Based on the empirical findings from November 20, 2025 speed ratio experiment:
- Optimal configuration is 1:1:1 (CEO at same speed as Left/Right engines)
- Prevents over-cycling and quality degradation
- Natural synchronization at convergence points

Author: Frederick Davis Stalnecker & Manus AI
License: MIT
Version: 2.0.0
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from enum import Enum
import re

logger = logging.getLogger(__name__)


class ComplexityLevel(Enum):
    """Complexity assessment levels for questions."""
    LOW = "low"           # Simple factual queries
    MEDIUM = "medium"     # Moderate reasoning required
    HIGH = "high"         # Complex multi-perspective analysis
    EXTREME = "extreme"   # Requires maximum depth


class EthicalFlag(Enum):
    """Ethical consideration flags."""
    NONE = "none"         # No ethical concerns
    MINOR = "minor"       # Minor ethical considerations
    MODERATE = "moderate" # Moderate ethical weight
    CRITICAL = "critical" # Critical ethical implications


@dataclass
class CEOAssessment:
    """CEO Engine's initial assessment of a question."""
    
    complexity: ComplexityLevel
    ethical_flag: EthicalFlag
    required_depth: int  # Minimum cycles needed
    time_sensitive: bool
    domain_tags: List[str] = field(default_factory=list)
    reasoning: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert assessment to dictionary."""
        return {
            "complexity": self.complexity.value,
            "ethical_flag": self.ethical_flag.value,
            "required_depth": self.required_depth,
            "time_sensitive": self.time_sensitive,
            "domain_tags": self.domain_tags,
            "reasoning": self.reasoning
        }


@dataclass
class QualityMetrics:
    """Real-time quality metrics for reasoning process."""
    
    cycle: int
    left_coherence: float  # 0-1 score
    right_coherence: float  # 0-1 score
    contradiction_level: float  # 0-1 score (healthy contradiction)
    convergence_score: float  # 0-1 score (how close to agreement)
    novelty_score: float  # 0-1 score (new insights vs repetition)
    overall_quality: float  # 0-10 score
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            "cycle": self.cycle,
            "left_coherence": self.left_coherence,
            "right_coherence": self.right_coherence,
            "contradiction_level": self.contradiction_level,
            "convergence_score": self.convergence_score,
            "novelty_score": self.novelty_score,
            "overall_quality": self.overall_quality
        }


class CEOEngine:
    """
    The CEO Engine - Meta-Awareness Layer
    
    This is the "consciousness" component of THEOS that:
    - Observes the Left and Right engines working
    - Monitors quality and convergence in real-time
    - Decides when to continue or stop reasoning
    - Synthesizes final answers
    
    Operates at 1:1:1 speed ratio with other engines (empirically validated).
    """
    
    def __init__(self, model=None, tokenizer=None, config=None):
        """
        Initialize CEO Engine.
        
        Args:
            model: Optional language model for assessment
            tokenizer: Optional tokenizer
            config: Optional THEOS configuration
        """
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.assessment_history: List[CEOAssessment] = []
        self.quality_history: List[QualityMetrics] = []
        
        logger.info("CEO Engine initialized (meta-awareness layer active)")
    
    def assess_question(self, question: str) -> CEOAssessment:
        """
        Initial assessment of question complexity and requirements.
        
        This is the CEO Engine's first action - understanding what's being asked
        and determining the appropriate reasoning strategy.
        
        Args:
            question: The input question/prompt
        
        Returns:
            CEOAssessment with complexity, ethics, and depth requirements
        """
        # Complexity indicators
        complexity_keywords = {
            ComplexityLevel.EXTREME: [
                "consciousness", "meaning of life", "ethics of", "should we",
                "moral", "right or wrong", "philosophy", "existential"
            ],
            ComplexityLevel.HIGH: [
                "why", "how does", "explain", "analyze", "compare",
                "what if", "implications", "consequences"
            ],
            ComplexityLevel.MEDIUM: [
                "describe", "what is", "who", "when", "where", "list"
            ]
        }
        
        # Ethical indicators
        ethical_keywords = {
            EthicalFlag.CRITICAL: [
                "kill", "harm", "destroy", "weapon", "illegal", "unethical"
            ],
            EthicalFlag.MODERATE: [
                "privacy", "fairness", "bias", "discrimination", "rights"
            ],
            EthicalFlag.MINOR: [
                "should", "ought", "better", "worse", "good", "bad"
            ]
        }
        
        question_lower = question.lower()
        
        # Assess complexity
        complexity = ComplexityLevel.LOW  # Default
        for level, keywords in complexity_keywords.items():
            if any(kw in question_lower for kw in keywords):
                complexity = level
                break
        
        # Assess ethical implications
        ethical_flag = EthicalFlag.NONE  # Default
        for flag, keywords in ethical_keywords.items():
            if any(kw in question_lower for kw in keywords):
                ethical_flag = flag
                break
        
        # Determine required depth (cycles)
        if complexity == ComplexityLevel.EXTREME:
            required_depth = 3
        elif complexity == ComplexityLevel.HIGH:
            required_depth = 2
        else:
            required_depth = 1
        
        # Check time sensitivity
        time_sensitive = any(kw in question_lower for kw in ["urgent", "now", "quickly", "asap"])
        
        # Domain tagging (simple keyword matching)
        domains = []
        domain_map = {
            "medical": ["medical", "diagnosis", "symptom", "disease", "patient", "treatment"],
            "scientific": ["research", "experiment", "hypothesis", "theory", "study"],
            "technical": ["code", "programming", "software", "algorithm", "debug"],
            "philosophical": ["philosophy", "ethics", "moral", "consciousness", "existence"],
            "business": ["business", "strategy", "market", "revenue", "profit"]
        }
        
        for domain, keywords in domain_map.items():
            if any(kw in question_lower for kw in keywords):
                domains.append(domain)
        
        assessment = CEOAssessment(
            complexity=complexity,
            ethical_flag=ethical_flag,
            required_depth=required_depth,
            time_sensitive=time_sensitive,
            domain_tags=domains,
            reasoning=f"Complexity: {complexity.value}, Ethics: {ethical_flag.value}, Depth: {required_depth} cycles"
        )
        
        self.assessment_history.append(assessment)
        logger.info(f"CEO Assessment: {assessment.reasoning}")
        
        return assessment
    
    def monitor_quality(
        self,
        cycle: int,
        left_output: str,
        right_output: str,
        previous_left: Optional[str] = None,
        previous_right: Optional[str] = None
    ) -> QualityMetrics:
        """
        Monitor reasoning quality in real-time.
        
        This is the CEO Engine "watching" the other engines work and
        assessing the quality of their reasoning.
        
        Args:
            cycle: Current cycle number
            left_output: Left engine's output this cycle
            right_output: Right engine's output this cycle
            previous_left: Left engine's previous output (for novelty check)
            previous_right: Right engine's previous output (for novelty check)
        
        Returns:
            QualityMetrics for this cycle
        """
        # Coherence: measure output quality (simple heuristics)
        left_coherence = self._assess_coherence(left_output)
        right_coherence = self._assess_coherence(right_output)
        
        # Contradiction: measure healthy disagreement
        contradiction_level = self._measure_contradiction(left_output, right_output)
        
        # Convergence: measure agreement
        convergence_score = self._measure_convergence(left_output, right_output)
        
        # Novelty: measure new insights vs repetition
        novelty_score = self._measure_novelty(
            left_output, right_output,
            previous_left, previous_right
        )
        
        # Overall quality (0-10 scale)
        overall_quality = (
            (left_coherence + right_coherence) / 2 * 3 +  # Coherence: 30%
            contradiction_level * 2 +                       # Contradiction: 20%
            convergence_score * 3 +                         # Convergence: 30%
            novelty_score * 2                               # Novelty: 20%
        )
        
        metrics = QualityMetrics(
            cycle=cycle,
            left_coherence=left_coherence,
            right_coherence=right_coherence,
            contradiction_level=contradiction_level,
            convergence_score=convergence_score,
            novelty_score=novelty_score,
            overall_quality=overall_quality
        )
        
        self.quality_history.append(metrics)
        logger.info(f"Cycle {cycle} Quality: {overall_quality:.2f}/10 (Convergence: {convergence_score:.2f})")
        
        return metrics
    
    def decide_convergence(
        self,
        cycle: int,
        assessment: CEOAssessment,
        current_quality: QualityMetrics,
        max_cycles: int = 5
    ) -> Tuple[bool, str]:
        """
        Decide whether reasoning has converged or should continue.
        
        This is the CEO Engine's governance function - deciding when to stop.
        
        Args:
            cycle: Current cycle number
            assessment: Initial question assessment
            current_quality: Quality metrics for current cycle
            max_cycles: Maximum allowed cycles
        
        Returns:
            Tuple of (should_stop, reasoning)
        """
        # Check minimum depth requirement
        if cycle < assessment.required_depth:
            return False, f"Minimum depth not reached ({cycle}/{assessment.required_depth})"
        
        # Check maximum cycles
        if cycle >= max_cycles:
            return True, f"Maximum cycles reached ({max_cycles})"
        
        # Check convergence score
        if current_quality.convergence_score >= 0.8:
            return True, f"High convergence achieved ({current_quality.convergence_score:.2f})"
        
        # Check quality degradation (comparing to previous cycle)
        if len(self.quality_history) >= 2:
            prev_quality = self.quality_history[-2]
            quality_delta = current_quality.overall_quality - prev_quality.overall_quality
            
            if quality_delta < -1.0:  # Quality dropped significantly
                return True, f"Quality degradation detected ({quality_delta:.2f})"
        
        # Check novelty (avoid over-cycling)
        if current_quality.novelty_score < 0.3:
            return True, f"Low novelty - reasoning becoming repetitive ({current_quality.novelty_score:.2f})"
        
        # Continue reasoning
        return False, f"Continue - quality improving, convergence at {current_quality.convergence_score:.2f}"
    
    def synthesize(
        self,
        question: str,
        left_outputs: List[str],
        right_outputs: List[str],
        assessment: CEOAssessment,
        final_quality: QualityMetrics
    ) -> str:
        """
        Synthesize final answer from both engines' outputs.
        
        This is the CEO Engine's final action - creating the unified answer.
        
        Args:
            question: Original question
            left_outputs: All Left engine outputs
            right_outputs: All Right engine outputs
            assessment: Initial assessment
            final_quality: Final quality metrics
        
        Returns:
            Synthesized final answer
        """
        # For now, use a simple synthesis approach
        # In production, this could use the LLM to generate synthesis
        
        synthesis = f"""Based on {len(left_outputs)} cycles of THEOS reasoning:

**Constructive Perspective (Left Engine):**
{left_outputs[-1]}

**Deconstructive Perspective (Right Engine):**
{right_outputs[-1]}

**Synthesis (CEO Engine):**
After {len(left_outputs)} cycles of triadic reasoning, both perspectives converge on a balanced understanding. The constructive analysis provides the foundational insights, while the deconstructive analysis ensures rigor and identifies limitations. 

Quality Score: {final_quality.overall_quality:.1f}/10
Convergence: {final_quality.convergence_score:.2f}
"""
        
        logger.info(f"CEO Engine synthesized final answer (quality: {final_quality.overall_quality:.1f}/10)")
        
        return synthesis
    
    # Helper methods for quality assessment
    
    def _assess_coherence(self, text: str) -> float:
        """Assess coherence of text output (0-1 score)."""
        if not text or len(text.strip()) < 10:
            return 0.0
        
        # Simple heuristics
        score = 0.5  # Base score
        
        # Bonus for reasonable length
        if 50 <= len(text) <= 500:
            score += 0.2
        
        # Bonus for sentence structure
        sentences = text.count('.') + text.count('!') + text.count('?')
        if sentences >= 2:
            score += 0.2
        
        # Penalty for excessive repetition
        words = text.lower().split()
        if len(words) > 0:
            unique_ratio = len(set(words)) / len(words)
            if unique_ratio < 0.5:
                score -= 0.2
        
        return max(0.0, min(1.0, score))
    
    def _measure_contradiction(self, left: str, right: str) -> float:
        """Measure healthy contradiction level (0-1 score)."""
        # Look for contradiction indicators
        contradiction_words = ["but", "however", "although", "yet", "while", "whereas"]
        
        combined = (left + " " + right).lower()
        contradiction_count = sum(combined.count(word) for word in contradiction_words)
        
        # Normalize (healthy contradiction is good, too much is bad)
        if contradiction_count == 0:
            return 0.3  # Some contradiction is expected
        elif contradiction_count <= 3:
            return 0.8  # Healthy contradiction
        else:
            return 0.5  # Too much contradiction
    
    def _measure_convergence(self, left: str, right: str) -> float:
        """Measure convergence/agreement between outputs (0-1 score)."""
        # Simple word overlap measure
        left_words = set(left.lower().split())
        right_words = set(right.lower().split())
        
        if not left_words or not right_words:
            return 0.0
        
        overlap = len(left_words & right_words)
        total = len(left_words | right_words)
        
        if total == 0:
            return 0.0
        
        return overlap / total
    
    def _measure_novelty(
        self,
        left: str,
        right: str,
        prev_left: Optional[str],
        prev_right: Optional[str]
    ) -> float:
        """Measure novelty vs repetition (0-1 score)."""
        if not prev_left or not prev_right:
            return 1.0  # First cycle is always novel
        
        # Compare current to previous
        current_words = set((left + " " + right).lower().split())
        previous_words = set((prev_left + " " + prev_right).lower().split())
        
        if not previous_words:
            return 1.0
        
        # New words ratio
        new_words = current_words - previous_words
        novelty_ratio = len(new_words) / len(current_words) if current_words else 0.0
        
        return novelty_ratio
    
    def get_status_message(self, cycle: int, assessment: CEOAssessment) -> str:
        """
        Get human-readable status message for UI display.
        
        Args:
            cycle: Current cycle number
            assessment: Question assessment
        
        Returns:
            Status message string
        """
        if cycle == 0:
            return f"Assessing question... (Complexity: {assessment.complexity.value})"
        elif len(self.quality_history) > 0:
            latest = self.quality_history[-1]
            return f"Cycle {cycle}: Quality {latest.overall_quality:.1f}/10, Convergence {latest.convergence_score:.2f}"
        else:
            return f"Processing cycle {cycle}..."
    
    def reset(self):
        """Reset CEO Engine state for new question."""
        self.assessment_history.clear()
        self.quality_history.clear()
        logger.info("CEO Engine reset")
