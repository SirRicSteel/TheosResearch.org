# THEOS Benchmarking Guide

**Complete guide to benchmarking THEOS and validating performance claims**

---

## 📋 Overview

This benchmarking suite validates THEOS's core claims:
- **50-65% energy reduction** vs. standard transformer inference
- **Intelligent caching** with high hit rates on repeated queries
- **Convergent reasoning** that stops at optimal quality points

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
# Core dependencies (required)
pip install transformers torch

# Visualization dependencies (optional but recommended)
pip install matplotlib
```

### 2. Run Benchmark

```bash
# Quick test (3 prompts, ~2 minutes)
python benchmark_suite.py --model distilgpt2 --quick-test

# Full benchmark (12 prompts, ~10 minutes)
python benchmark_suite.py --model distilgpt2

# Benchmark with larger model
python benchmark_suite.py --model gpt2
```

### 3. Analyze Results

```bash
# Analyze latest results
python analyze_results.py benchmark_results/*.json

# Generate report without charts
python analyze_results.py benchmark_results/*.json --no-charts

# Specify output file
python analyze_results.py benchmark_results/*.json --output my_report.md
```

---

## 📊 What Gets Measured

### 1. Energy Efficiency Benchmark

**Measures:**
- Total inference time (THEOS vs. baseline)
- Total tokens generated
- Tokens per second
- Average cycles per query

**Validates:**
- Time reduction percentage
- Token reduction percentage
- Overall efficiency gain

**Expected Results:**
- 50-65% time reduction
- 40-60% token reduction
- 3-5 average cycles to convergence

### 2. Cache Performance Benchmark

**Measures:**
- Cache hit rate on repeated queries
- First run time vs. cached run time
- Speedup factor from caching

**Validates:**
- WisdomCache effectiveness
- LRU + TTL eviction strategy
- Production deployment viability

**Expected Results:**
- 90-100% hit rate on exact repeats
- 10-100x speedup on cache hits
- Minimal memory overhead

### 3. Convergence Analysis

**Measures:**
- Convergence rate at different cycle limits
- Average cycles used vs. maximum allowed
- Relationship between cycles and quality

**Validates:**
- Governor effectiveness
- Convergence detection accuracy
- Optimal cycle count

**Expected Results:**
- 60-80% convergence rate at 5 cycles
- 80-95% convergence rate at 7 cycles
- Diminishing returns beyond 7 cycles

---

## 🔬 Benchmark Methodology

### Test Prompts

The benchmark uses 12 diverse prompts covering:

**Philosophical Reasoning** (3 prompts)
- Tests abstract concept synthesis
- Validates triadic dialectic effectiveness

**Logical Reasoning** (3 prompts)
- Tests deductive inference
- Validates structured argumentation

**Creative Reasoning** (3 prompts)
- Tests imaginative synthesis
- Validates constructive vortex

**Analytical Reasoning** (3 prompts)
- Tests comparative analysis
- Validates deconstructive vortex

### Baseline Comparison

**Baseline Method:**
- Standard `model.generate()` with same parameters
- Temperature: 0.7, Top-p: 0.9, Top-k: 50
- Max tokens: 50 (same as THEOS)

**THEOS Method:**
- Triadic reasoning with convergence detection
- Max cycles: 5 (configurable)
- Same generation parameters
- WisdomCache enabled

### Metrics Collection

**Timing:**
- Python `time.time()` for wall-clock measurement
- Separate timing for each phase
- Cache hit/miss timing

**Token Counting:**
- Input tokens vs. output tokens
- Total tokens across all cycles
- Tokens per cycle breakdown

**Quality Indicators:**
- Convergence boolean (did it converge?)
- Governor scores per cycle
- Cache hit boolean

---

## 📈 Interpreting Results

### Energy Efficiency

**Good Results:**
```
Time Reduction:       50-65%
Token Reduction:      40-60%
Efficiency Gain:      50-65%
Avg Cycles per Query: 3-5
```

**What This Means:**
- THEOS uses ~50% less compute than baseline
- Converges in 3-5 cycles on average
- Suitable for production deployment

**If Results Are Lower:**
- Check model size (smaller models may show less benefit)
- Verify prompts are complex enough to benefit from reasoning
- Consider increasing max_cycles if convergence rate is low

### Cache Performance

**Good Results:**
```
Cache Hit Rate:       90-100%
Speedup Factor:       10-100x
First Run Time:       0.5-2.0s
Cached Run Time:      0.01-0.05s
```

**What This Means:**
- Cache is working correctly
- Repeated queries are nearly instant
- Production systems will see major speedup

**If Results Are Lower:**
- Check if prompts are identical (cache is exact-match)
- Verify TTL hasn't expired between runs
- Ensure cache is enabled in config

### Convergence Analysis

**Good Results:**
```
Max Cycles: 3  | Convergence Rate: 40-60% | Avg Cycles Used: 2.5-2.8
Max Cycles: 5  | Convergence Rate: 60-80% | Avg Cycles Used: 3.5-4.2
Max Cycles: 7  | Convergence Rate: 80-95% | Avg Cycles Used: 4.5-5.5
Max Cycles: 10 | Convergence Rate: 90-100% | Avg Cycles Used: 5.0-6.5
```

**What This Means:**
- Governor is detecting convergence correctly
- Most queries converge before max cycles
- Optimal setting is 5-7 cycles for balance

**If Results Are Different:**
- Lower convergence may indicate complex prompts (good!)
- Higher cycles may indicate threshold is too strict
- Adjust `convergence_threshold` in config if needed

---

## 🎯 Recommended Configurations

### For Maximum Energy Savings

```python
config = THEOSConfig(
    max_cycles=3,              # Aggressive early stopping
    min_cycles=2,              # Minimum quality threshold
    convergence_threshold=0.15, # Looser convergence
    max_tokens=30,             # Shorter responses
    enable_cache=True          # Cache everything
)
```

**Use When:**
- Cost/energy is primary concern
- Acceptable to sacrifice some quality
- High query repetition expected

### For Maximum Quality

```python
config = THEOSConfig(
    max_cycles=10,             # Allow more reasoning
    min_cycles=3,              # Higher quality floor
    convergence_threshold=0.05, # Stricter convergence
    max_tokens=100,            # Longer responses
    enable_cache=True          # Still cache
)
```

**Use When:**
- Quality is paramount
- Energy cost is acceptable
- Complex reasoning required

### For Production Balance

```python
config = THEOSConfig(
    max_cycles=5,              # Default - good balance
    min_cycles=2,              # Standard minimum
    convergence_threshold=0.1,  # Default threshold
    max_tokens=50,             # Reasonable length
    enable_cache=True          # Production essential
)
```

**Use When:**
- Deploying to production
- Need balance of quality and cost
- Typical use case

---

## 📝 Benchmark Report Structure

The generated markdown report includes:

### 1. Executive Summary
- Key findings in 2-3 sentences
- Headline metrics (time reduction, cache hit rate)

### 2. Energy Efficiency Results
- Comparison table (THEOS vs. baseline)
- Time and token reduction percentages
- Average cycles per query

### 3. Cache Performance Results
- Hit rate statistics
- Speedup factors
- First run vs. cached run times

### 4. Convergence Analysis
- Convergence rates at different cycle limits
- Average cycles used
- Optimal configuration recommendations

### 5. Methodology
- Test setup details
- Benchmark descriptions
- Reproducibility information

### 6. Conclusions
- Summary of findings
- Validation of claims
- Recommendations for deployment

---

## 🔧 Advanced Usage

### Custom Test Prompts

Edit `benchmark_suite.py` and modify `self.test_prompts`:

```python
self.test_prompts = [
    "Your custom prompt 1",
    "Your custom prompt 2",
    # ... add more
]
```

### Multiple Models

```bash
# Benchmark multiple models
python benchmark_suite.py --model distilgpt2
python benchmark_suite.py --model gpt2
python benchmark_suite.py --model gpt2-medium

# Analyze all results together
python analyze_results.py benchmark_results/*.json
```

### Custom Configurations

Modify the `THEOSConfig` in benchmark methods:

```python
config = THEOSConfig(
    max_cycles=7,              # Your custom value
    convergence_threshold=0.08, # Your custom threshold
    # ... other parameters
)
```

### Power Measurement (Advanced)

For actual power consumption measurement:

```python
# Add to benchmark_suite.py
import subprocess

def measure_power():
    # Linux: Use powertop or similar
    result = subprocess.run(['powerstat', '-R', '1', '1'], 
                          capture_output=True, text=True)
    # Parse result for watts
    return watts
```

---

## 📊 Visualization Charts

If matplotlib is installed, `analyze_results.py` generates:

### 1. energy_efficiency.png
- Bar charts showing time and token reduction
- Visual comparison of THEOS vs. baseline

### 2. cache_performance.png
- Cache hit rates across models
- Speedup factors visualization

### 3. convergence_analysis.png
- Line chart of convergence rate vs. cycle limit
- Shows optimal cycle count

**Charts are saved to:** `benchmark_results/` directory

---

## 🐛 Troubleshooting

### "Model not found"
```bash
# Download model first
python -c "from transformers import AutoModelForCausalLM; AutoModelForCausalLM.from_pretrained('gpt2')"
```

### "Out of memory"
```bash
# Use smaller model
python benchmark_suite.py --model distilgpt2

# Or reduce batch size in code
```

### "Matplotlib not found"
```bash
# Install visualization dependencies
pip install matplotlib

# Or skip charts
python analyze_results.py results/*.json --no-charts
```

### Slow benchmarks
```bash
# Use quick test mode
python benchmark_suite.py --quick-test

# Or use smaller model
python benchmark_suite.py --model distilgpt2
```

---

## 📚 Next Steps

After running benchmarks:

1. **Review the generated report** - Check if results match expectations
2. **Share results** - Include in papers, presentations, or documentation
3. **Tune configuration** - Adjust based on your specific needs
4. **Run on production data** - Test with real queries from your application
5. **Measure actual power** - Use hardware tools for precise energy measurement

---

## 📞 Support

For questions about benchmarking:
- Review this guide thoroughly
- Check the generated report for insights
- Examine the JSON results files for raw data
- Contact: guestent@gmail.com

---

**THEOS Benchmarking Suite - Validate the Claims, Prove the Performance** 🧠⚡
