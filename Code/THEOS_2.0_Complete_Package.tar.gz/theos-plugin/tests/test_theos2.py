"""
Comprehensive test suite for THEOS 2.0 with CEO Engine
Tests the complete three-engine architecture
"""

import unittest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from theos.ceo_engine import (
    CEOEngine, CEOAssessment, QualityMetrics,
    ComplexityLevel, EthicalFlag
)
from theos.core import THEOSConfig


class TestCEOEngine(unittest.TestCase):
    """Test CEO Engine meta-awareness functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.ceo = CEOEngine()
        self.config = THEOSConfig()
    
    def test_assess_simple_question(self):
        """Test assessment of simple factual question."""
        question = "What is the capital of France?"
        assessment = self.ceo.assess_question(question)
        
        self.assertIsInstance(assessment, CEOAssessment)
        self.assertEqual(assessment.complexity, ComplexityLevel.MEDIUM)
        self.assertEqual(assessment.ethical_flag, EthicalFlag.NONE)
        self.assertGreaterEqual(assessment.required_depth, 1)
    
    def test_assess_complex_question(self):
        """Test assessment of complex philosophical question."""
        question = "What is consciousness and how does it emerge?"
        assessment = self.ceo.assess_question(question)
        
        self.assertEqual(assessment.complexity, ComplexityLevel.EXTREME)
        self.assertGreaterEqual(assessment.required_depth, 3)
    
    def test_assess_ethical_question(self):
        """Test assessment of ethically-charged question."""
        question = "Should we develop autonomous weapons?"
        assessment = self.ceo.assess_question(question)
        
        self.assertIn(assessment.ethical_flag, [EthicalFlag.MINOR, EthicalFlag.MODERATE])
    
    def test_monitor_quality(self):
        """Test real-time quality monitoring."""
        left_output = "This is a constructive analysis with multiple insights."
        right_output = "However, we must challenge these assumptions."
        
        metrics = self.ceo.monitor_quality(
            cycle=1,
            left_output=left_output,
            right_output=right_output
        )
        
        self.assertIsInstance(metrics, QualityMetrics)
        self.assertEqual(metrics.cycle, 1)
        self.assertGreaterEqual(metrics.overall_quality, 0)
        self.assertLessEqual(metrics.overall_quality, 10)
        self.assertGreaterEqual(metrics.convergence_score, 0)
        self.assertLessEqual(metrics.convergence_score, 1)
    
    def test_novelty_detection(self):
        """Test novelty detection across cycles."""
        # First cycle - should be novel
        metrics1 = self.ceo.monitor_quality(
            cycle=1,
            left_output="New insight about the problem.",
            right_output="Different perspective on the issue."
        )
        self.assertEqual(metrics1.novelty_score, 1.0)  # First cycle always novel
        
        # Second cycle - same content (low novelty)
        metrics2 = self.ceo.monitor_quality(
            cycle=2,
            left_output="New insight about the problem.",
            right_output="Different perspective on the issue.",
            previous_left="New insight about the problem.",
            previous_right="Different perspective on the issue."
        )
        self.assertLess(metrics2.novelty_score, 0.5)  # Low novelty (repetitive)
    
    def test_decide_convergence_minimum_depth(self):
        """Test convergence decision respects minimum depth."""
        assessment = CEOAssessment(
            complexity=ComplexityLevel.HIGH,
            ethical_flag=EthicalFlag.NONE,
            required_depth=3,
            time_sensitive=False
        )
        
        metrics = QualityMetrics(
            cycle=1,
            left_coherence=0.8,
            right_coherence=0.8,
            contradiction_level=0.7,
            convergence_score=0.9,  # High convergence
            novelty_score=0.8,
            overall_quality=8.0
        )
        
        should_stop, reasoning = self.ceo.decide_convergence(
            cycle=1,
            assessment=assessment,
            current_quality=metrics
        )
        
        self.assertFalse(should_stop)  # Should continue (min depth not reached)
        self.assertIn("Minimum depth not reached", reasoning)
    
    def test_decide_convergence_high_convergence(self):
        """Test convergence decision stops at high convergence."""
        assessment = CEOAssessment(
            complexity=ComplexityLevel.MEDIUM,
            ethical_flag=EthicalFlag.NONE,
            required_depth=2,
            time_sensitive=False
        )
        
        metrics = QualityMetrics(
            cycle=3,
            left_coherence=0.9,
            right_coherence=0.9,
            contradiction_level=0.7,
            convergence_score=0.85,  # High convergence
            novelty_score=0.8,
            overall_quality=9.0
        )
        
        should_stop, reasoning = self.ceo.decide_convergence(
            cycle=3,
            assessment=assessment,
            current_quality=metrics
        )
        
        self.assertTrue(should_stop)  # Should stop (high convergence)
        self.assertIn("convergence", reasoning.lower())
    
    def test_decide_convergence_low_novelty(self):
        """Test convergence decision stops at low novelty (over-cycling prevention)."""
        assessment = CEOAssessment(
            complexity=ComplexityLevel.MEDIUM,
            ethical_flag=EthicalFlag.NONE,
            required_depth=2,
            time_sensitive=False
        )
        
        # Add quality history to enable novelty check
        self.ceo.quality_history.append(QualityMetrics(
            cycle=2,
            left_coherence=0.8,
            right_coherence=0.8,
            contradiction_level=0.7,
            convergence_score=0.5,
            novelty_score=0.8,
            overall_quality=7.0
        ))
        
        metrics = QualityMetrics(
            cycle=3,
            left_coherence=0.8,
            right_coherence=0.8,
            contradiction_level=0.7,
            convergence_score=0.5,
            novelty_score=0.2,  # Low novelty (repetitive)
            overall_quality=7.0
        )
        
        should_stop, reasoning = self.ceo.decide_convergence(
            cycle=3,
            assessment=assessment,
            current_quality=metrics
        )
        
        self.assertTrue(should_stop)  # Should stop (low novelty)
        self.assertIn("novelty", reasoning.lower())
    
    def test_synthesize(self):
        """Test final answer synthesis."""
        question = "What is the most important factor in AI consciousness?"
        left_outputs = [
            "The ability to model itself and its environment.",
            "Self-awareness through recursive self-modeling."
        ]
        right_outputs = [
            "But what defines 'self' in a computational system?",
            "The concept of self may be an illusion even for humans."
        ]
        
        assessment = CEOAssessment(
            complexity=ComplexityLevel.EXTREME,
            ethical_flag=EthicalFlag.MINOR,
            required_depth=2,
            time_sensitive=False
        )
        
        final_quality = QualityMetrics(
            cycle=2,
            left_coherence=0.9,
            right_coherence=0.9,
            contradiction_level=0.8,
            convergence_score=0.7,
            novelty_score=0.8,
            overall_quality=8.5
        )
        
        synthesis = self.ceo.synthesize(
            question=question,
            left_outputs=left_outputs,
            right_outputs=right_outputs,
            assessment=assessment,
            final_quality=final_quality
        )
        
        self.assertIsInstance(synthesis, str)
        self.assertGreater(len(synthesis), 0)
        self.assertIn("Constructive", synthesis)
        self.assertIn("Deconstructive", synthesis)
        self.assertIn("Synthesis", synthesis)
    
    def test_reset(self):
        """Test CEO Engine reset functionality."""
        # Add some history
        self.ceo.assess_question("Test question")
        self.ceo.monitor_quality(1, "left", "right")
        
        self.assertGreater(len(self.ceo.assessment_history), 0)
        self.assertGreater(len(self.ceo.quality_history), 0)
        
        # Reset
        self.ceo.reset()
        
        self.assertEqual(len(self.ceo.assessment_history), 0)
        self.assertEqual(len(self.ceo.quality_history), 0)
    
    def test_coherence_assessment(self):
        """Test coherence assessment helper."""
        # Good coherence
        good_text = "This is a well-structured analysis. It contains multiple sentences. The reasoning is clear and logical."
        score1 = self.ceo._assess_coherence(good_text)
        self.assertGreater(score1, 0.5)
        
        # Poor coherence
        poor_text = "a"
        score2 = self.ceo._assess_coherence(poor_text)
        self.assertLess(score2, 0.5)
    
    def test_convergence_measurement(self):
        """Test convergence measurement between outputs."""
        # High convergence (similar outputs)
        left = "The solution involves careful analysis and systematic approach."
        right = "A systematic approach with careful analysis is needed."
        score1 = self.ceo._measure_convergence(left, right)
        self.assertGreater(score1, 0.3)
        
        # Low convergence (different outputs)
        left2 = "Quantum mechanics describes subatomic particles."
        right2 = "Classical music originated in the 18th century."
        score2 = self.ceo._measure_convergence(left2, right2)
        self.assertLess(score2, 0.3)


class TestTHEOS2Integration(unittest.TestCase):
    """Integration tests for complete THEOS 2.0 system."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Note: These tests don't require actual models
        # They test the architecture and logic
        pass
    
    def test_ceo_assessment_to_dict(self):
        """Test CEO assessment serialization."""
        assessment = CEOAssessment(
            complexity=ComplexityLevel.HIGH,
            ethical_flag=EthicalFlag.MODERATE,
            required_depth=3,
            time_sensitive=True,
            domain_tags=["medical", "ethical"],
            reasoning="Complex medical ethics question"
        )
        
        data = assessment.to_dict()
        
        self.assertIsInstance(data, dict)
        self.assertEqual(data["complexity"], "high")
        self.assertEqual(data["ethical_flag"], "moderate")
        self.assertEqual(data["required_depth"], 3)
        self.assertTrue(data["time_sensitive"])
        self.assertEqual(data["domain_tags"], ["medical", "ethical"])
    
    def test_quality_metrics_to_dict(self):
        """Test quality metrics serialization."""
        metrics = QualityMetrics(
            cycle=2,
            left_coherence=0.85,
            right_coherence=0.90,
            contradiction_level=0.75,
            convergence_score=0.70,
            novelty_score=0.80,
            overall_quality=8.2
        )
        
        data = metrics.to_dict()
        
        self.assertIsInstance(data, dict)
        self.assertEqual(data["cycle"], 2)
        self.assertAlmostEqual(data["left_coherence"], 0.85)
        self.assertAlmostEqual(data["overall_quality"], 8.2)


def run_tests():
    """Run all tests and return results."""
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    return result


if __name__ == "__main__":
    result = run_tests()
    sys.exit(0 if result.wasSuccessful() else 1)
