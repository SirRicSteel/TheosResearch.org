# THEOS Benchmark Results

This directory contains benchmark results from the THEOS performance validation suite.

## 📁 File Structure

```
benchmark_results/
├── README.md                              # This file
├── benchmark_<model>_<timestamp>.json     # Raw benchmark data
├── BENCHMARK_REPORT_<timestamp>.md        # Generated analysis report
├── energy_efficiency.png                  # Energy savings visualization
├── cache_performance.png                  # Cache hit rate visualization
└── convergence_analysis.png               # Convergence behavior visualization
```

## 🔍 Understanding Result Files

### JSON Result Files

Raw benchmark data in JSON format containing:
- **metadata**: Model name, timestamp, environment info
- **benchmarks**: Array of benchmark results
  - energy_efficiency: Time/token reduction metrics
  - cache_performance: Hit rates and speedup factors
  - convergence_analysis: Convergence rates at different cycle limits

**Example filename:** `benchmark_distilgpt2_20241210_143022.json`

### Markdown Report Files

Human-readable analysis reports containing:
- Executive summary with key findings
- Detailed results tables
- Methodology description
- Conclusions and recommendations

**Example filename:** `BENCHMARK_REPORT_20241210_143045.md`

### Visualization Files

PNG charts showing:
- **energy_efficiency.png**: Bar charts of time/token reduction
- **cache_performance.png**: Cache hit rates and speedup
- **convergence_analysis.png**: Convergence rate vs. cycle limit

## 📊 Quick Analysis

To analyze existing results:

```bash
# Analyze all results in this directory
python ../analyze_results.py *.json

# Analyze specific result file
python ../analyze_results.py benchmark_distilgpt2_*.json

# Generate report without charts
python ../analyze_results.py *.json --no-charts
```

## 🎯 Expected Results

**Energy Efficiency:**
- Time Reduction: 50-65%
- Token Reduction: 40-60%
- Avg Cycles: 3-5

**Cache Performance:**
- Hit Rate: 90-100% (on exact repeats)
- Speedup: 10-100x

**Convergence:**
- 60-80% convergence at 5 cycles
- 80-95% convergence at 7 cycles

## 📝 Notes

- Results vary by model size and complexity
- Smaller models (distilgpt2) may show less benefit
- Cache performance depends on query repetition
- Convergence rates depend on prompt complexity

## 🔄 Re-running Benchmarks

To generate new results:

```bash
# Quick test
python ../benchmark_suite.py --model distilgpt2 --quick-test

# Full benchmark
python ../benchmark_suite.py --model distilgpt2

# Different model
python ../benchmark_suite.py --model gpt2
```

Results will be automatically saved to this directory.

---

**For detailed benchmarking instructions, see:** `../BENCHMARKING_GUIDE.md`
