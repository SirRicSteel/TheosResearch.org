#!/usr/bin/env python3
"""
Quick test of THEOS 2.0 with CEO Engine
"""

import sys
import os

# Add theos to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from transformers import GPT2LMHeadModel, GPT2Tokenizer
from theos.theos_v2 import THEOS2

def main():
    print("=" * 70)
    print("THEOS 2.0 - Quick Test")
    print("=" * 70)
    print()
    
    # Load model
    print("Loading model...")
    model = GPT2LMHeadModel.from_pretrained("distilgpt2")
    tokenizer = GPT2Tokenizer.from_pretrained("distilgpt2")
    print("✓ Model loaded\n")
    
    # Initialize THEOS 2.0
    print("Initializing THEOS 2.0 with CEO Engine...")
    theos = THEOS2(model, tokenizer)
    print("✓ THEOS 2.0 initialized\n")
    
    # Test question
    question = "What is the most important factor in achieving consciousness in AI?"
    
    print(f"Question: {question}")
    print()
    
    # Run reasoning with verbose output
    print("Running THEOS 2.0 reasoning...")
    print()
    
    response = theos.reason(question, return_metadata=True, verbose=True)
    
    # Display results
    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)
    print()
    print(f"Cycles: {response.cycles}")
    print(f"Converged: {response.converged}")
    print(f"Time: {response.time_elapsed:.2f}s")
    print()
    
    if response.ceo_assessment:
        print("CEO Assessment:")
        print(f"  - Complexity: {response.ceo_assessment['complexity']}")
        print(f"  - Ethical Flag: {response.ceo_assessment['ethical_flag']}")
        print(f"  - Required Depth: {response.ceo_assessment['required_depth']} cycles")
        print()
    
    if response.quality_metrics:
        print("Quality Metrics (Final Cycle):")
        final_metrics = response.quality_metrics[-1]
        print(f"  - Overall Quality: {final_metrics['overall_quality']:.1f}/10")
        print(f"  - Convergence Score: {final_metrics['convergence_score']:.2f}")
        print(f"  - Novelty Score: {final_metrics['novelty_score']:.2f}")
        print()
    
    if response.convergence_reasoning:
        print(f"Convergence Reasoning: {response.convergence_reasoning}")
        print()
    
    print("Final Answer:")
    print("-" * 70)
    print(response.text)
    print("-" * 70)
    print()
    
    print("✓ THEOS 2.0 test complete!")

if __name__ == "__main__":
    main()
