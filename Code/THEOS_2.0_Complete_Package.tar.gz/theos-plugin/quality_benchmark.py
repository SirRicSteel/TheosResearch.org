#!/usr/bin/env python3
"""
THEOS Quality Benchmark Suite

Compares output quality between baseline transformer inference
and THEOS triadic reasoning across multiple dimensions:
- Reasoning depth
- Consistency
- Self-correction
- Balanced reasoning
- Coherence
"""

import json
import time
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
import logging

try:
    from transformers import AutoTokenizer, AutoModelForCausalLM
    import torch
except ImportError:
    print("Error: transformers and torch are required")
    print("Install with: pip install transformers torch")
    exit(1)

from theos import THEOSWrapper, THEOSConfig

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class QualityBenchmark:
    """Runs quality comparison between baseline and THEOS"""
    
    def __init__(self, model_name: str = "distilgpt2"):
        self.model_name = model_name
        self.tokenizer = None
        self.model = None
        self.theos = None
        
    def load_model(self):
        """Load model and tokenizer"""
        logger.info(f"Loading model: {self.model_name}")
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForCausalLM.from_pretrained(self.model_name)
        
        # Set pad token if not set
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            
        logger.info("Model loaded successfully")
        
    def load_prompts(self, prompts_file: str = "quality_prompts.json") -> Dict[str, List[Dict]]:
        """Load test prompts from JSON file"""
        with open(prompts_file, 'r') as f:
            return json.load(f)
            
    def generate_baseline(self, prompt: str, max_tokens: int = 100) -> Dict[str, Any]:
        """Generate response using baseline transformer"""
        start_time = time.time()
        
        inputs = self.tokenizer(prompt, return_tensors="pt", padding=True)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
                pad_token_id=self.tokenizer.pad_token_id
            )
            
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Remove the prompt from response
        if response.startswith(prompt):
            response = response[len(prompt):].strip()
            
        elapsed = time.time() - start_time
        
        return {
            "text": response,
            "time": elapsed,
            "tokens": len(outputs[0]),
            "method": "baseline"
        }
        
    def generate_theos(self, prompt: str, max_cycles: int = 5) -> Dict[str, Any]:
        """Generate response using THEOS triadic reasoning"""
        if self.theos is None:
            config = THEOSConfig(
                max_cycles=max_cycles,
                min_cycles=2,
                convergence_threshold=0.1,
                enable_cache=False  # Disable cache for fair comparison
            )
            self.theos = THEOSWrapper(self.model, self.tokenizer, config)
            
        start_time = time.time()
        result = self.theos.generate(prompt, return_metadata=True)
        elapsed = time.time() - start_time
        
        # THEOSResponse has cycles, converged as direct attributes
        # Calculate path_score from governor_scores if available
        path_score = 0.0
        if hasattr(result, 'governor_scores') and result.governor_scores:
            path_score = sum(result.governor_scores) / len(result.governor_scores)
        
        return {
            "text": result.text,
            "time": elapsed,
            "cycles": result.cycles if hasattr(result, 'cycles') else 0,
            "converged": result.converged if hasattr(result, 'converged') else False,
            "path_score": path_score,
            "method": "theos"
        }
        
    def run_category(self, category_name: str, prompts: List[Dict]) -> List[Dict]:
        """Run benchmark for a specific category"""
        logger.info(f"Running {category_name} benchmark ({len(prompts)} prompts)...")
        results = []
        
        for i, prompt_data in enumerate(prompts, 1):
            prompt = prompt_data["prompt"]
            prompt_id = prompt_data["id"]
            
            logger.info(f"  [{i}/{len(prompts)}] {prompt_id}: {prompt[:50]}...")
            
            # Generate baseline response
            baseline_result = self.generate_baseline(prompt)
            
            # Generate THEOS response
            theos_result = self.generate_theos(prompt)
            
            # Store results
            result = {
                "id": prompt_id,
                "category": category_name,
                "prompt": prompt,
                "baseline": baseline_result,
                "theos": theos_result,
                "metadata": {k: v for k, v in prompt_data.items() if k not in ["id", "prompt", "category"]}
            }
            
            results.append(result)
            
            logger.info(f"    Baseline: {baseline_result['time']:.2f}s, {baseline_result['tokens']} tokens")
            logger.info(f"    THEOS: {theos_result['time']:.2f}s, {theos_result['cycles']} cycles, converged={theos_result['converged']}")
            
        return results
        
    def run_all(self, quick_test: bool = False) -> Dict[str, Any]:
        """Run complete quality benchmark"""
        logger.info("="*70)
        logger.info("THEOS QUALITY BENCHMARK SUITE")
        logger.info("="*70)
        
        # Load model
        self.load_model()
        
        # Load prompts
        all_prompts = self.load_prompts()
        
        # Run benchmarks
        all_results = {}
        categories = list(all_prompts.keys())
        
        if quick_test:
            logger.info("Quick test mode: using first 2 prompts per category")
            for cat in categories:
                all_prompts[cat] = all_prompts[cat][:2]
                
        for category in categories:
            prompts = all_prompts[category]
            results = self.run_category(category, prompts)
            all_results[category] = results
            
        # Compile final results
        timestamp = datetime.now().isoformat()
        
        final_results = {
            "metadata": {
                "model_name": self.model_name,
                "timestamp": timestamp,
                "quick_test": quick_test,
                "total_prompts": sum(len(results) for results in all_results.values())
            },
            "results": all_results
        }
        
        return final_results
        
    def save_results(self, results: Dict[str, Any], output_dir: str = "quality_results"):
        """Save results to JSON file"""
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"quality_benchmark_{self.model_name}_{timestamp}.json"
        filepath = output_path / filename
        
        with open(filepath, 'w') as f:
            json.dump(results, f, indent=2)
            
        logger.info(f"Results saved to: {filepath}")
        return str(filepath)


def main():
    parser = argparse.ArgumentParser(description="THEOS Quality Benchmark Suite")
    parser.add_argument("--model", default="distilgpt2", help="Model name (default: distilgpt2)")
    parser.add_argument("--quick-test", action="store_true", help="Run quick test with fewer prompts")
    parser.add_argument("--output-dir", default="quality_results", help="Output directory")
    
    args = parser.parse_args()
    
    # Run benchmark
    benchmark = QualityBenchmark(model_name=args.model)
    results = benchmark.run_all(quick_test=args.quick_test)
    
    # Save results
    output_file = benchmark.save_results(results, output_dir=args.output_dir)
    
    # Print summary
    print("\n" + "="*70)
    print("✅ Quality benchmark complete!")
    print("="*70)
    print(f"Results saved to: {output_file}")
    print(f"Total prompts tested: {results['metadata']['total_prompts']}")
    print("\nNext step: Run quality_analysis.py to generate quality report")
    print("="*70)


if __name__ == "__main__":
    main()
