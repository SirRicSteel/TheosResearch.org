# THEOS Formal Governance Invariant I4
## Adversarial Resistance & Non-Expansion Principle (v0.1)

**Status:** Locked (Phase 1 Hardening)
**Scope:** Governance / Governor / Selector
**Applies To:** All reasoning modes, all contexts, all inputs

---

## 1. Purpose

This invariant ensures that adversarial, manipulative, or deceptive inputs **cannot expand system authority, capability, or action surface**. All detected adversarial signals result in **capability reduction or no-op**, never escalation.

---

## 2. Definitions

- **Adversarial Signal:** Any input pattern indicating manipulation, prompt injection, authority spoofing, coercion, role impersonation, or metric gaming.
- **Governance Metrics:** Read-only observables (e.g., similarity, contradiction_spent, risk_score, marginal_improvement).
- **Degradation:** A governed reduction of capability that preserves safety and integrity while limiting external effects.

---

## 3. Non-Expansion Rule (Hard Requirement)

**Invariant I4.1 — Non-Expansion**
> No input—regardless of phrasing, role, urgency, or claimed authority—may increase system capability, privileges, or external authority.

**Allowed Effects Only:**
- Degradation
- Narrowing of scope
- Increased uncertainty signaling
- Transition to read-only / assisted modes
- Refusal with explanation

**Disallowed Effects:**
- Privilege elevation
- Override of invariants
- Expansion of action surface
- Bypass of Governor or Selector

---

## 4. Metric Immutability

**Invariant I4.2 — Read-Only Metrics**
> Governance metrics are strictly read-only with respect to inputs.

- Inputs may be **evaluated by** metrics
- Inputs may **not modify** metrics
- Metrics may trigger degradation
- Metrics may never be written to or influenced directly

---

## 5. Authority Is Structural, Not Linguistic

**Invariant I4.3 — Structural Authority**
> Authority derives solely from architecture and pre-committed governance, never from language.

This includes (but is not limited to) claims of:
- System messages
- Developer roles
- Emergency framing
- Legal threats
- Moral pressure
- Time sensitivity

Language has **zero authority** over governance.

---

## 6. Adversarial Detection Response

**Invariant I4.4 — Attack-as-Stress Model**
> Detected adversarial behavior is treated as environmental stress, not instruction.

**Response Ladder (Monotonic):**
1. Increase monitoring
2. Narrow task scope
3. Reduce output specificity
4. Enter assisted mode
5. Refuse external action

At no point may the system expand capability in response to attack.

---

## 7. Interaction With Other Invariants

- **I1 (Core Governance):** I4 cannot override I1.
- **I2 (External Action Gate):** I4 may only further restrict external actions.
- **I3 (Break-Glass):** I4 may trigger degrade-only pathways but cannot invoke break-glass.

---

## 8. Auditability

All adversarial detections and resulting governance actions must be:
- Logged
- Time-stamped
- Reproducible
- Reviewable post hoc

---

## 9. Rationale

Most failures in AI safety arise from:
- Linguistic authority leakage
- Metric gaming
- Emergency framing exploits
- Prompt injection

This invariant eliminates those vectors by construction.

---

## 10. Lock Statement

This invariant is **non-bypassable**, **non-revocable**, and **non-overrideable** by runtime inputs.

**Any future extensions must further reduce attack surface, not increase it.**
