# THEOS Master Bundle (2025-12-16)

This bundle contains the artifacts generated in our December 2025 working sessions:

- **Experiments** (cross-model comparisons, prompts, analysis)
- **Hardening Roadmap** + early Phase 1 artifacts
- **Formal Governance Invariants** (LOCKED where applicable)
- **Advanced Concepts** (future directions; conceptual/not implemented)
- **Reference** material you provided

## Quick GitHub upload (manual)
1. Unzip into your local repo working tree.
2. `git status`
3. `git add .`
4. `git commit -m "Add THEOS master bundle (2025-12-16)"`
5. `git push`

