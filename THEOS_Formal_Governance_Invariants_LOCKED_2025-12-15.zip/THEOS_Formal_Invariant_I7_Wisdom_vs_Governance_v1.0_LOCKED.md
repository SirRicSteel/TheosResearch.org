# I7 Wisdom vs Governance

LOCKED
